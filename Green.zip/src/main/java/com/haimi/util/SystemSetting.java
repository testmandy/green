package com.haimi.util;

import java.io.IOException;
import java.util.Properties;

/**
 * 配置文件读取设置
 * 
 * @author iris
 *
 */
public class SystemSetting {

	static String filepath = "data.properties";

	/**
	 * 通过配置文件data获取环境值 test online mockonline
	 * 
	 * @param key
	 * @return
	 */
	private static String getProperty(String key) {
		// 配置文件
		Properties properties = new Properties();
		try {
			properties.load(SystemSetting.class.getClassLoader().getResourceAsStream(filepath));
			return properties.getProperty(key);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 获取url，dburl，username，password的值 如果非maven运行，则直接返回115环境的值
	 * 
	 * @return
	 */
	public static String getUrl() {
		String url = getProperty("baseUrl");
		if (!url.startsWith("$"))
			return url;
		// return "http://115.236.16.44/api";
		return "http://api.haimi.com/api";
	}

	public static String getDBUrl() {
		String url = getProperty("DBUrl");
		if (!url.startsWith("$"))
			return url;
		// return "jdbc:mysql://115.236.16.44:3307/daigou";
		// return "jdbc:mysql://192.168.1.248:3306/haitao";
		return "jdbc:mysql://183.131.23.134:10095/daigou";
	}

	public static String getUserName() {
		String url = getProperty("username");
		if (!url.startsWith("$"))
			return url;
		// return "haimidev";
		// return "root";
		return "haimiselect";
	}

	public static String getPassWord() {
		String url = getProperty("password");
		if (!url.startsWith("$"))
			return url;
		// return "dashi123";
		// return "123456";
		return "duomai&Passhaimi";
	}
}
