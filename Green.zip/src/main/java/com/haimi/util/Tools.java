package com.haimi.util;

import java.util.HashMap;
import java.util.Random;

import org.testng.Assert;

/**
 * 工具类
 * 
 * @author iris
 *
 */
public class Tools {

	/**
	 * 获取时间戳
	 * 
	 * @return
	 */
	public static String getTimeStamp() {
		return "" + System.currentTimeMillis();
	}

	/**
	 * 获取随机字符串
	 * 
	 * @param length
	 * @return
	 */
	public static String getRandomString(int length) {
		String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		Random random = new Random();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < length; i++) {
			int number = random.nextInt(62);
			sb.append(str.charAt(number));
		}
		return sb.toString();
	}

	/**
	 * 获取随机数字串
	 * 
	 * @param length
	 * @return
	 */
	public static String getRandomNum(int length) {
		String str = "0123456789";
		Random random = new Random();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < length; i++) {
			int number = random.nextInt(10);
			sb.append(str.charAt(number));
		}
		return sb.toString();
	}

	/**
	 * 根据String获取hashmap
	 * 
	 * “Deposited=N, pageSize=20, page=1, Promotion=N,CreditDeduct=N,
	 * Subject=网易严选”
	 * 
	 * @param text
	 * @return
	 */
	public static HashMap<String, String> getM(String text) {
		HashMap<String, String> map = new HashMap<String, String>();
		String[] kvs = text.split(",");
		for (int i = 0; i < kvs.length; i++) {
			String[] kv = kvs[i].split("=");
			map.put(kv[0], kv[1]);
		}
		Assert.assertTrue(!map.isEmpty(), "获取的hashmap数据为空");
		return map;
	}
}
