package com.haimi.util;

import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.log4j.Logger;

/**
 * 参数帮助类
 * 
 * @author iris
 *
 */

public class ParamsWorker {

	// log4j
	static Logger logger = Logger.getLogger(ParamsWorker.class.getName());

	/**
	 * 判断传入参数为null的字符串时，该参数不传
	 * 
	 * @param params
	 * @param name
	 * @param value
	 */
	public static void addParams(List<NameValuePair> params, String name, String value) {
		if ("null".equals(value)) {
			return;
		}
		params.add(new BasicNameValuePair(name, value));
		logger.info("为请求设置参数" + name + ",值为：" + value);
	}

}
