package com.haimi.util;

/**
 * 加密签名的公钥和key存储
 * 
 * @author iris
 *
 */
public class KeyString {

	// 加密的公钥
	public static final String DEFAULT_PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDlnksmkkZe7nIASYQ3UWSyGtaC"
			+ "\r" + "GAwPMaUEbbeLA1GV6a2NHpoFnT+mvMwUoQfJ+Tkvpe15uGIB2NCvCoR1mL4y0Mgv" + "\r"
			+ "zQ3z8ef704CPHYdQCzcC+M+F6KzvKR4miADAhv/EPjzxA7Op/XErKFTwrBm1Fih2" + "\r" + "t0+yRUWF3av304arSQIDAQAB"
			+ "\r";

	public static final String SECURITY_NONSTR = "_security_nonstr";

	public static final String SECURITY_SIGN = "_security_sign";

	// 签名的key
	public static final String KEY = "026971549765EEFB94466C78D47928A2";
}
