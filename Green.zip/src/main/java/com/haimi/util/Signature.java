package com.haimi.util;

import java.util.List;
import java.util.Set;
import java.util.TreeMap;

import org.apache.http.NameValuePair;
import org.apache.log4j.Logger;

import com.haimi.encoder.MD5Utils;
import com.haimi.encoder.RSAUtils;

/**
 * 签名加密处理
 * 
 * @author iris
 *
 */
public class Signature {

	// log4j
	static Logger logger = Logger.getLogger(Signature.class.getName());

	/**
	 * 对url进行加密
	 * 
	 * @param url
	 * @param list
	 * @return
	 */
	public static String getSignatureUrl(String url, List<NameValuePair> list) {
		// 生成随机数
		String randomValue = MD5Utils.getRandomString(10);
		// 用treemap存储参数
		TreeMap<String, String> baseparams = new TreeMap<String, String>();

		// 接口有传参的，将参数传入map
		if (list != null) {
			for (NameValuePair pair : list) {
				baseparams.put(pair.getName(), pair.getValue());
			}
		}

		// 添加随机数
		baseparams.put(KeyString.SECURITY_NONSTR, randomValue);

		// 生成字符串
		Set<String> keySet = baseparams.keySet();
		StringBuilder builder = new StringBuilder();
		for (String keytmp : keySet) {
			builder.append(keytmp);
			builder.append("=");
			String value = baseparams.get(keytmp);
			if (null == value) {
				value = "";
			}

			builder.append(value);
			builder.append("&");
		}
		if (builder.length() > 0 && builder.toString().endsWith("&")) {
			builder.deleteCharAt(builder.length() - 1);
		}
		builder.append("&key=");
		builder.append(KeyString.KEY);

		// 签名
		String md5 = MD5Utils.getMD5(builder.toString());
		String signMd5 = md5.toUpperCase();
		url = url + "?" + KeyString.SECURITY_NONSTR + "=" + randomValue + "&" + KeyString.SECURITY_SIGN + "=" + signMd5;
		logger.debug("签名后的url为：" + url);
		return url;
	}

	/**
	 * 对密码进行公钥的RSA加密
	 * 
	 * @param password
	 * @return
	 */
	public static String encrypt(String password) {
		try {
			password = RSAUtils.encryptByPublicKey(password.getBytes());
			logger.debug("密码加密完成，加密后：" + password);
			return password;
		} catch (Exception e) {
			logger.error("密码加密失败");
			e.printStackTrace();
			return null;
		}
	}

}
