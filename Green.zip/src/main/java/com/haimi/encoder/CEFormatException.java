package com.haimi.encoder;

import java.io.IOException;

/**
 * CEFormatException定义
 * 
 * @author iris
 *
 */
public class CEFormatException extends IOException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8375038592661523590L;

	public CEFormatException(String s) {
		super(s);
	}
}
