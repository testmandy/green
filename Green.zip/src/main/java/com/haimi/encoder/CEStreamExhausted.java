package com.haimi.encoder;

import java.io.IOException;

/**
 * CEStreamExhausted自定义
 * 
 * @author iris
 *
 */
public class CEStreamExhausted extends IOException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1866188826385600278L;

}
