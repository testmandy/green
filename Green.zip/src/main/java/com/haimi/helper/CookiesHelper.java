package com.haimi.helper;

import java.util.List;

import org.apache.http.client.CookieStore;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.apache.log4j.Logger;

/**
 * 模拟cookie的方法
 * 
 * @author iris
 *
 */
public class CookiesHelper {

	// log4j
	static Logger logger = Logger.getLogger(CookiesHelper.class.getName());

	static CookieStore cookieStore;

	/**
	 * 模拟初始cookie
	 * 
	 * @param version
	 *            客户端版本 3.6.0及以上版本需要加密和验签
	 * @param appName
	 *            客户端app名称 haimi or mibao
	 * @param platform
	 *            客户端平台 IOS or ANDROID
	 * @return
	 */
	public static CookieStore setCookie(String url, String version, String appName, String platform) {
		// 开始伪造cookie
		cookieStore = new BasicCookieStore();

		String domain = url.split("/")[2];

		BasicClientCookie cookie1 = new BasicClientCookie("currentVersion", version);
		cookie1.setDomain(domain);
		cookie1.setPath("/");

		BasicClientCookie cookie2 = new BasicClientCookie("appName", appName);
		cookie2.setDomain(domain);
		cookie2.setPath("/");

		BasicClientCookie cookie3 = new BasicClientCookie("platform", platform);
		cookie3.setDomain(domain);
		cookie3.setPath("/");

		// 将cookie添加到cookiestore
		cookieStore.addCookie(cookie1);
		cookieStore.addCookie(cookie2);
		cookieStore.addCookie(cookie3);

		logger.info("伪造cookie为：" + version + ";" + appName + ";" + platform);

		return cookieStore;
	}

	/**
	 * 判断当前cookie中的海蜜版本号是否大于等于3.6.0，是返回true，否则返回flase
	 * 
	 * @param cookiestore
	 * @return
	 */
	public static boolean isCookieVersionNew(CookieStore cookiestore) {
		String appname = getCookieValue(cookiestore, "appName");
		if (!"haimi".equals(appname.toLowerCase().trim())) {
			logger.info("此cookies不需要加密，appname为：" + appname);
			return false;
		}
		String version = getCookieValue(cookiestore, "currentVersion");
		String[] num = version.split("\\.");
		if (Integer.parseInt(num[0]) > 3)
			return true;
		else if (Integer.parseInt(num[0]) == 3 && Integer.parseInt(num[1]) > 5)
			return true;
		else {
			logger.info("此cookies不需要加密，version为：" + version);
			return false;
		}
	}

	/**
	 * 获取cookie集合中的key的value值
	 * 
	 * @param cookiestore
	 * @param key
	 * @return
	 */
	public static String getCookieValue(CookieStore cookiestore, String key) {
		List<Cookie> cookies = cookiestore.getCookies();
		if (cookies.isEmpty()) {
			logger.error("这个cookie是空的");
			return null;
		} else {
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals(key)) {
					logger.info("此cookie中key：" + key + ",对应的value为：" + cookie.getValue());
					return cookie.getValue();
				} else
					continue;
			}
		}
		logger.error("此cookie中key：" + key + ",对应的value为空");
		return null;
	}

	public static void main(String args[]) {
		CookieStore cookiestore = CookiesHelper.setCookie("https://api.haimi.com/api", "5.2.0", "haimi", "ANDROID");
		System.out.println(CookiesHelper.isCookieVersionNew(cookiestore));
		System.out.println(CookiesHelper.getCookieValue(cookiestore, "currentVersion"));
		// String domain= CommonStrings.baseUrl.split("/")[2];
		// System.out.println("111"+domain);
	}
}
