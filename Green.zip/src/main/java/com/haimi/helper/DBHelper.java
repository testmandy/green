package com.haimi.helper;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.haimi.util.SystemSetting;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

/**
 * 数据库数据处理
 * 
 * @author iris
 *
 */
public class DBHelper {

	static Logger logger = Logger.getLogger(DBHelper.class.getName());

	// 数据库连接数据
	static String name = "com.mysql.jdbc.Driver";

	static Connection con = null;

	/**
	 * 数据库连接
	 * 
	 * @param url
	 * @param username
	 * @param password
	 */
	protected static void connect(String url, String username, String password) {
		try {
			Class.forName(name);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			con = (Connection) DriverManager.getConnection(url, username, password);
			logger.info("数据库连接建立成功：" + url);
		} catch (SQLException e) {
			logger.error("数据库连接失败：" + url);
			e.printStackTrace();
		}
	}

	/**
	 * 使用默认连接
	 */
	public static void connect() {
		connect(SystemSetting.getDBUrl(), SystemSetting.getUserName(), SystemSetting.getPassWord());
	}

	/**
	 * 数据查询，返回查询结果
	 * 
	 * @param sql
	 * @return
	 */
	public static ResultSet select(String sql) {
		try {
			PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			logger.info("查询sql语句完成：" + sql);
			return rs;
		} catch (SQLException e) {
			logger.error("查询失败：" + sql);
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 获取查询结果的第一行的指定列的结果
	 * 
	 * @param set
	 * @param lable
	 * @return
	 */
	public static Object getFirstObjectResult(ResultSet set, String lable) {
		if (set == null) {
			logger.error("需要查询的结果集为空");
			return null;
		}

		try {
			if (set.first()) {
				Object result = set.getObject(lable);
				logger.info("查询列" + lable + "的结果是" + result.toString());
				return result;
			} else {
				logger.info("该结果集没有结果，无法查询第一行");
				return null;
			}
		} catch (SQLException e) {
			logger.error("查询结果的列" + lable + "获取失败");
			e.printStackTrace();
		}
		return null;
	}

	// /**
	// * 获取查询结果的第一行的指定列的String结果
	// *
	// * @param set
	// * @param lable
	// * @return
	// */
	// public static String getFirstStringResult(ResultSet set, String lable) {
	// if (set == null) {
	// logger.error("需要查询的结果集为空");
	// return null;
	// }
	// try {
	// set.first();
	// String result = set.getString(lable);
	// logger.info("查询列" + lable + "的结果是" + result);
	// return result;
	// } catch (SQLException e) {
	// logger.error("查询结果的列" + lable + "获取失败");
	// e.printStackTrace();
	// }
	// return null;
	// }

	// /**
	// * 插入数据，线上用例不要使用此方法
	// *
	// * @param sql
	// * "insert into member_amounts (MemberID,Currency,Balance,IsDefault)
	// values (?,?,?,?)"
	// * @param values
	// * memberid,"CNY", money, "1"
	// * @return
	// */
	// public static int insert(String sql, String... values) {
	//
	// try {
	// PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
	// for (int i = 0; i < values.length; i++) {
	// pst.setString(i + 1, values[i]);
	// logger.info((i + 1) + "个参数的值是：" + values[i]);
	// }
	// int row = pst.executeUpdate();
	// logger.info("插入数据成功，sql：" + sql + ";影响行数：" + row);
	// pst.close();
	// return row;
	// } catch (SQLException e) {
	// e.printStackTrace();
	// }
	// return 0;
	// }
	//
	// /**
	// * 更新数据,线上用例不要使用此方法
	// *
	// * @param sql
	// */
	// public static int update(String sql) {
	// try {
	// PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
	// int row = pst.executeUpdate();
	// logger.info("更新数据成功，sql：" + sql + ";影响行数：" + row);
	// pst.close();
	// return row;
	// } catch (SQLException e) {
	// e.printStackTrace();
	// }
	// return 0;
	// }

	/**
	 * 关闭数据连接
	 */
	public static void close() {
		try {
			if (con == null || con.isClosed())
				return;
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		try {
			con.close();
			logger.info("数据连接关闭成功");
		} catch (SQLException e) {
			logger.error("数据连接关闭失败");
			e.printStackTrace();
		}
	}

	public static void main(String args[]) {
		DBHelper.connect();
		ResultSet rs = DBHelper
				.select("select Name from live_ad_modules where Alias='" + "discovery" + "' order by CreateTime DESC");

		try {
			System.out.println(rs == null);
		} finally {
			DBHelper.close();
		}

	}
}
