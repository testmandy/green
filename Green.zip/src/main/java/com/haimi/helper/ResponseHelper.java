package com.haimi.helper;

import org.apache.log4j.Logger;
import org.testng.Assert;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * json数据的比较方法
 * 
 * @author iris
 *
 */
public class ResponseHelper {

	// log4j
	static Logger logger = Logger.getLogger(ResponseHelper.class.getName());

	/**
	 * 比较json中的key对应的值，是否和提供的value值相同 针对单层json
	 * 
	 * @param json
	 * @param key
	 * @param value
	 * @return
	 */
	public static void compareJSON(JSONObject json, String key, String value) {
		boolean isOk = false;
		String responseValue = null;
		if (json != null && json.has(key)) {
			responseValue = json.getString(key);
			if (responseValue.equals(value)) {
				isOk = true;
				logger.info(String.format("比较找到key:%s value:%s", key, value));
			}
		}
		Assert.assertTrue(isOk, String.format("没找到key:%s value:%s，实际获取到的是：%s", key, value, responseValue));
	}

	/**
	 * 比较正定的response的名为son的子json的key对应的值，和提供的value值是否相等
	 * 针对2层json，比较的是第二层json的key-value值
	 * 
	 * @param response
	 * @param son
	 * @param key
	 * @param value
	 * @return
	 */
	public static void compareSonJSON(JSONObject response, String son, String key, String value) {
		JSONObject sonjson = response.getJSONObject(son);
		compareJSON(sonjson, key, value);
	}

	/**
	 * 比较指定response的名为arrayname的jsonarray中第arrayindex个的jsonobject中的key对应的值，
	 * 是否和提供的value值相同 针对父json中有一个jsonarray数组，该json数组中的一个元素为json，比较这个子json的key值
	 * 三层的json，中间层为json数组
	 * 
	 * @param response
	 * @param arrayIndex
	 * @param key
	 * @param value
	 * @return
	 */
	public static void compareArrayJSON(JSONObject response, String arrayname, int arrayIndex, String key,
			String value) {
		JSONArray array = response.getJSONArray(arrayname);
		JSONObject data = array.getJSONObject(arrayIndex);
		compareJSON(data, key, value);
	}

	/**
	 * 判断请求的flag值 如果flag不符合，则用例失败，并打印msg内容
	 * 
	 * @param text
	 */
	public static void compareFlag(JSONObject json, Object flag) {
		Object flags = json.get("flag");
		logger.info("开始比较flag的值，期望值为：" + flags + "实际值为：" + flag + ",返回消息为：" + json.getString("msg"));
		Assert.assertEquals(flags, flag, json.getString("msg"));
	}

	/**
	 * 判断请求的msg和需求是否相同，如果不相同，用例失败
	 * 
	 * @param json
	 * @param msg
	 */
	public static void compareMsg(JSONObject json, String msg) {
		String msgs = json.getString("msg");
		logger.info("开始比较msg的值，期望值为：" + msgs + "实际值为：" + msg + ",返回消息为：" + json.getString("msg"));
		Assert.assertEquals(msgs, msg, json.getString("msg"));
	}

	/**
	 * 判断响应中是否包含指定的字符串
	 * 
	 * @param json
	 * @param value
	 */
	public static void containsString(JSONObject json, String value) {
		String text = json.toString();
		boolean flag = text.contains(value);
		Assert.assertTrue(flag, "指定的json数据中不包含字符串：" + value);
	}
}
