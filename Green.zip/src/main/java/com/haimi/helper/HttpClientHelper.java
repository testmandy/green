package com.haimi.helper;

import java.io.IOException;
import java.util.List;

import org.apache.http.Consts;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.CookieStore;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.testng.Assert;

import com.haimi.util.Signature;

import net.sf.json.JSONObject;

/**
 * http请求辅助类
 * 
 * @author iris
 *
 */
public class HttpClientHelper {

	// log4j
	static Logger logger = Logger.getLogger(HttpClientHelper.class.getName());

	/**
	 * post基本方法
	 * 
	 * @param client
	 * @param url
	 * @param params
	 * @param headers
	 * @return String
	 */
	private static JSONObject post(CloseableHttpClient client, String url, List<NameValuePair> params,
			Header[] headers) {
		// 通过url新建httppost实例
		HttpPost post = new HttpPost(url);
		logger.info("测试url为：" + url);

		// 设置headers
		if (headers != null) {
			post.setHeaders(headers);
			logger.info("为请求设置header，头部设置栏目个数为：" + headers.length);
		}

		try {
			// 设置拼接参数
			if (params != null) {
				UrlEncodedFormEntity reqentity = new UrlEncodedFormEntity(params, "utf-8");
				post.setEntity(reqentity);
			}

			// 执行post请求
			CloseableHttpResponse res = client.execute(post);

			// 如果请求返回200，并且实体非空，返回请求的实体String
			if (res.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = res.getEntity();
				if (entity != null) {
					String response = EntityUtils.toString(entity, "utf-8");
					return JSONHelper.stringToJSON(response);
				} else {
					logger.error("请求的返回实体为空！！");
					Assert.fail("请求的返回实体为空！！");
				}
			} else {
				logger.error("请求的返回码是：" + res.getStatusLine().getStatusCode());
				Assert.fail("请求的返回码是：" + res.getStatusLine().getStatusCode());
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// 无论如何释放post请求，返回连接
			post.releaseConnection();
			logger.info("post请求释放");
			try {
				client.close();
				logger.info("client关闭");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	/**
	 * post方法
	 * 
	 * @param url
	 * @param cookie
	 * @return
	 */
	public static JSONObject post(String url, CookieStore cookie) {
		if (CookiesHelper.isCookieVersionNew(cookie)) {
			url = Signature.getSignatureUrl(url, null);
		}
		return post(HttpClients.custom().setDefaultCookieStore(cookie).build(), url, null, null);
	}

	/**
	 * post请求
	 * 
	 * @param url
	 * @param params
	 * @param cookie
	 * @return
	 */
	public static JSONObject post(String url, List<NameValuePair> params, CookieStore cookie) {
		if (CookiesHelper.isCookieVersionNew(cookie)) {
			url = Signature.getSignatureUrl(url, params);
		}
		return post(HttpClients.custom().setDefaultCookieStore(cookie).build(), url, params, null);
	}

	/**
	 * post请求
	 * 
	 * @param url
	 * @param params
	 * @param cookie
	 * @param headers
	 * @return
	 */
	public static JSONObject postForm(String url, List<NameValuePair> params, Header[] headers, CookieStore cookie) {
		if (CookiesHelper.isCookieVersionNew(cookie)) {
			url = Signature.getSignatureUrl(url, params);
		}
		return post(HttpClients.custom().setDefaultCookieStore(cookie).build(), url, params, headers);
	}

	/**
	 * get请求
	 * 
	 * @param client
	 * @param url
	 * @return
	 */
	private static JSONObject get(CloseableHttpClient client, String url, List<NameValuePair> params) {
		// 由于是get请求，需要拼接参数到url上
		if (params != null) {
			String str = "";
			try {
				str = str + EntityUtils.toString(new UrlEncodedFormEntity(params, Consts.UTF_8));
			} catch (ParseException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			url = url + "?" + str;
		}
		// 创建get请求
		HttpGet get = new HttpGet(url);
		logger.info("测试url为：" + url);
		// 执行get请求
		try {
			CloseableHttpResponse res = client.execute(get);
			// 如果请求返回200，并且实体非空，返回请求的实体String
			if (res.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = res.getEntity();
				if (entity != null) {
					String response = EntityUtils.toString(entity, "utf-8");
					return JSONHelper.stringToJSON(response);
				} else {
					logger.error("请求的返回实体为空！！");
					Assert.fail("请求的返回实体为空！！");
				}
			} else {
				logger.error("请求的返回码是：" + res.getStatusLine().getStatusCode());
				Assert.fail("请求的返回码是：" + res.getStatusLine().getStatusCode());
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// 无论如何释放请求，返回连接
			get.releaseConnection();
			logger.info("get请求释放");
			try {
				client.close();
				logger.info("client关闭");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	/**
	 * get请求
	 * 
	 * @param url
	 * @param params
	 * @param cookie
	 * @return
	 */
	public static JSONObject get(String url, List<NameValuePair> params, CookieStore cookie) {
		return get(HttpClients.custom().setDefaultCookieStore(cookie).build(), url, params);
	}

	/**
	 * get请求
	 * 
	 * @param url
	 * @param cookie
	 * @return
	 */
	public static JSONObject get(String url, CookieStore cookie) {
		return get(HttpClients.custom().setDefaultCookieStore(cookie).build(), url, null);
	}

}
