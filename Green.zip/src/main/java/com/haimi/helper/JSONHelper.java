package com.haimi.helper;

import org.apache.log4j.Logger;
import org.testng.Assert;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * JSONObject的处理
 * 
 * @author iris
 *
 */
public class JSONHelper {

	static Logger logger = Logger.getLogger(JSONHelper.class.getName());

	/**
	 * 将请求返回的String转换为json格式
	 * 
	 * @param text
	 * @return
	 */
	public static JSONObject stringToJSON(String text) {
		JSONObject json = null;
		if (!text.startsWith("{")) {
			logger.error("请求返回的格式可能存在错误，json格式以非{开头，内容为：" + text);
			int a = text.indexOf("{");
			int b = text.lastIndexOf("}");
			text = text.substring(a, b + 1);
		}
		logger.debug("请求返回的String为：" + text);
		json = JSONObject.fromObject(text);
		if (json == null) {
			Assert.fail("返回的响应格式不正确，非JSON，请确认");
		}
		logger.info("转换后的json为：" + json);
		return json;
	}

	/**
	 * 返回父json的子json的key值
	 * 
	 * 2层嵌套
	 * 
	 * @param json
	 * @param key
	 * @return 取不到key值时，返回null
	 */
	public static Object getSonJSONKeyValue(JSONObject parent, String son, String key) {
		if (parent != null && parent.containsKey(son)) {
			JSONObject sonjson = parent.getJSONObject(son);
			if (sonjson != null && sonjson.containsKey(key)) {
				return sonjson.get(key);
			} else {
				logger.error("此json数据的子json" + son + "为空，或key：" + key + "不存在");
				return null;
			}
		} else {
			logger.error("此json数据为空或子json不存在");
			return null;
		}
	}

	/**
	 * 返回父json的arrayname的json数组中的第index个的jsonobject
	 * 3层，第二层为JSONArray，第3层为jsonobject
	 * 
	 * @param parent
	 * @param arrayname
	 * @param arrayindex
	 * @return 取不到key值时，返回null
	 */
	public static JSONObject getArraySonJSON(JSONObject parent, String arrayname, int arrayindex) {
		if (parent != null && parent.containsKey(arrayname)) {
			JSONArray sonarray = parent.getJSONArray(arrayname);
			if (sonarray != null && sonarray.size() > arrayindex) {
				JSONObject json = sonarray.getJSONObject(arrayindex);
				return json;
			} else {
				logger.error("此json数据的子array" + arrayname + "为空");
				return null;
			}
		} else {
			logger.error("此json数据为空");
			return null;
		}
	}

	public static void main(String args[]) {
		String s = "{\"flag\":1,\"msg\":\"\",\"data\":[],\"extra\":{}}";
		JSONObject json = JSONHelper.stringToJSON(s);

		String son = json.getString("aaa");
		System.out.println(son);
	}

}
