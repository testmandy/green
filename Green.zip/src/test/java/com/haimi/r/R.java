package com.haimi.r;

import com.haimi.util.SystemSetting;

/**
 * 记录所有api地址
 * 
 * @author iris
 *
 */
public class R {

	// 服务器基地址
	public static final String BASEURL = SystemSetting.getUrl();

	// 数据库基地址
	public static final String DBURL = SystemSetting.getDBUrl();
	public static final String USERNAME = SystemSetting.getUserName();
	public static final String PASSWORD = SystemSetting.getPassWord();

	// 登录
	public static final String MEMBER_LOGIN = "/member/login";
	public static final String MEMBER_LOGOUT = "/member/logout";

	// member
	public static final String MEMBER_QUICK_LOGIN = "/member/quick-login";
	public static final String MEMBER_SEND_QUICK_LOGIN_CODE = "/member/send-quick-login-code";
	public static final String MEMBER_SEND_REGISTER_MOBILE_CODE = "/member/send-register-mobile-code";
	public static final String MEMBER_REGISTER_BY_MOBILE_CODE = "/member/register-by-mobile-code"; // 此接口未测试，由于要一直产生新用户
	public static final String MEMBER_SETEMAIL = "/member/setemail";
	public static final String MEMBER_GET_EASEMOB_PASSWORD = "/member/get-easemob-password";
	public static final String MEMBER_RESET_PASSWORD = "/member/reset-password";
	public static final String MEMBER_SET_PASSWORD = "/member/set-password";
	public static final String MEMBER_SET_NEW_TRADE = "/member/set-new-trade";
	public static final String MEMBER_SEND_MERGE_ACCOUNT_CODE = "/member/send-merge-account-code";
	public static final String MEMBER_RESET_REFUND_PASSWORD = "/member/reset-refund-password";
	public static final String MEMBER_CUSTOM_CERTIFICATE_LIST = "/member/custom-certificate-list";
	public static final String MEMBER_SEND_RESET_PASSWORD_MOBILE = "/member/send-reset-password-mobile";
	public static final String MEMBER_SET_REFUND_PASSWORD = "/member/set-refund-password";
	public static final String MEMBER_SEND_NEW_MOBILE_CODE = "/member/send-new-mobile-code";
	public static final String MEMBER_CHECK_PASSWORD = "/member/check-password";
	public static final String MEMBER_CHECK_NEW_MOBILE_CODE = "/member/check-new-mobile-code";
	public static final String MEMBER_ADD_CUSTOM_CERTIFICATE = "/member/add-custom-certificate";
	public static final String MEMBER_SET_SELLER_PROFILE = "/member/set-seller-profile";
	public static final String MEMBER_SET_NEW_PASSWORD = "/member/set-new-password";
	public static final String MEMBER_SEND_RESET_TRADE_MOBILE = "/member/send-reset-trade-mobile";
	public static final String MEMBER_DELETE_REFUND_PASSWORD = "member/delete-refund-password";


	// me
	public static final String ME_PROFILE = "/me/profile";
	public static final String ME_OWN_INFO = "/me/own-info";
	public static final String ME_FAVORITES = "/me/favorites";
	public static final String ME_REMOVE_VIEW = "/me/remove-view";
	public static final String ME_BUYER_STATUS = "/me/buyer-status";
	public static final String ME_VIEW_LOG = "/me/view-log";
	public static final String ME_SHARE_CREDIT = "/me/share-credit";
	public static final String ME_GET_CREDIT_DETAIL = "/me/get-credit-detail";
	public static final String ME_GET_LOGIN_INFO = "me/get-login-info";

	// invite
	public static final String INVITE_PRESENT_GET = "/invite-present/get";
	public static final String INVITE_PRESENT_INDEX = "/invite-present/index";
	public static final String INVITE_PRESENT_RECEIVE = "/invite-present/receive";

	// cart
	public static final String CART_DELETE = "/cart/delete";
	public static final String CART_CHECKOUT_SINGLE = "/cart/checkout-single";
	public static final String CART_BATCH = "/cart/batch";
	public static final String CART_CHECKOUT = "/cart/checkout";
	public static final String CART_INFO = "/cart/info";
	public static final String CART_COUNT = "/cart/count";
	public static final String CART_PROMOTION_INFO = "/cart/promotion-info";
	public static final String CART_ADD = "/cart/add";
	public static final String CART_EDIT = "/cart/edit";
	public static final String CART_ORDER = "/cart/order";
	public static final String CART_GET_CONFIRM = "/cart/get-confirm";
	public static final String CART_CLEAR_INVALID_PRODUCT = "/cart/clear-invalid-products";

	// system
	public static final String SYSTEM_GET_CONFIG = "/system/get-config";
	public static final String SYSTEM_GET_MEIPAI_VIDEO_URL = "/system/get-meipai-video-url";
	public static final String SYSTEM_LOG_DEVICE_NOTIFICATION_STATUS = "/system/log-device-notification-status";
	public static final String SYSTEM_NO_ANSWER_CHAT = "/system/no-answer-chat";
	public static final String SYSTEM_GET_TIME = "/system/get-time";
	public static final String SYSTEM_GET_SETTING_INFO = "/system/get-setting-info";
	public static final String SYSTEM_IS_UPLOAD_CRASH_LOG = "/system/is-upload-crash-log";
	public static final String SYSTEM_API_PORTS = "/system/api-ports";
	public static final String SYSTEM_APP_UPDATE = "/system/app-update";
	public static final String SYSTEM_PING = "/system/ping";
	public static final String SYSTEM_SAVE_LOGIN_TIME = "/system/save-login-time";
	public static final String SYSTEM_STARTUP_IMAGES = "/system/startup-images";
	public static final String SYSTEM_GET_EXTRA_APP_INFO = "/system/get-extra-app-info";
	public static final String SYSTEM_GET_BRANDS = "/system/get-brands";
	public static final String SYSTEM_FAQ = "/system/faq";
	public static final String SYSTEM_GET_REFUND_REASON = "/system/get-refund-reason";
	public static final String SYSTEM_GET_RECOMMEND_PRODUCTS = "/system/get-recommend-products";
	public static final String SYSTEM_GETRECOMMEND = "/system/getrecommend";

	// ad
	public static final String AD_MODULE_GET = "/ad-module/get";
	public static final String AD_MODULE_DYNAMIC = "/ad-module/dynamic";

	// nav
	public static final String NAV_LIST = "/nav/list";
	public static final String NAV_ADVERT_TEAM_PRODUCTS = "/nav/advert-team-products";

	// search
	public static final String SEARCH_HOTWORD = "/search/hotword";
	public static final String SEARCH_SUGGEST = "/search/suggest";
	public static final String SEARCH_PRODUCT = "/search/product";

	// easemob
	public static final String EASEMOB_GET_VIRTUAL_BONUS_MESSAGE = "/easemob/get-virtual-bonus-message";

	// address
	public static final String ADDRESS_DELETE = "/address/delete";
	public static final String ADDRESS_LIST = "/address/list";
	public static final String ADDRESS_ADD = "/address/add";
	public static final String ADDRESS_SET_DEFAULT = "/address/set-default";
	public static final String ADDRESS_EDIT = "/address/edit";

	// user-sign
	public static final String USER_SIGN_INFO = "/user-sign/info";
	public static final String USER_SIGN_SIGN = "/user-sign/sign";
	// favorite
	public static final String FAVORITE_PRODUCT = "/favorite/product";
	public static final String FAVORITE_PRODUCT_CANCEL = "/favorite/product-cancel";

	// feedback
	public static final String FEEDBACK_POST = "/feedback/post";
	
	//escrow
	public static final String ESCROW_DETAIL="/escrow/detail";
	public static final String ESCROW_CREATE="/escrow/create";
	public static final String ESCROW_CANCEL="/escrow/cancel";
	public static final String ESCROW_SUGGEST_PRODUCTS="/escrow/suggest-products";
	public static final String ESCROW_PAY_ALL_MERGE="/escrow/pay-all-merge";
	public static final String ESCROW_BATCH_DETAILS="/escrow/batch-details";
	public static final String ESCROW_CUSTOM_INFO="/escrow/custom-info";
	
	
	public static final String ESCROW_BUYER_LIST="/escrow/buyer-list";
	public static final String ESCROW_GET_ARGUE_AMOUNT_DETAIL="/escrow/get-argue-amount-detail";
	public static final String ESCROW_ARGUE_DETAIL="/escrow/argue-detail";
	public static final String ESCROW_REMIND_SHIP="/escrow/remind-ship";
	public static final String ESCROW_APPLY_ARGUE="/escrow/apply-argue";
	public static final String ESCROW_CANCEL_ARGUE="/escrow/cancel-argue";
	public static final String ESCROW_DELETE="/escrow/delete";
	


}
