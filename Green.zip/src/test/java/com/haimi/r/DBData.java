package com.haimi.r;

import java.sql.ResultSet;
import java.sql.Timestamp;

import com.haimi.helper.DBHelper;

/**
 * 数据库数据操作数据集合
 * 
 * @author iris
 *
 */
public class DBData {

	/**
	 * 获取指定sql查询结果的第一行指定的列的value
	 * 
	 * @param sql
	 * @param key
	 * @return
	 */
	protected static Object getDBObject(String sql, String key) {
		Object value = null;
		try {
			// 数据库链接
			DBHelper.connect();
			// 数据库操作获取信息
			ResultSet set = DBHelper.select(sql);
			value = DBHelper.getFirstObjectResult(set, key);
		} finally {
			// 关闭数据库连接
			DBHelper.close();
		}
		return value;
	}

	/**
	 * 获取用户的email
	 * 
	 * @param memberid
	 * @return
	 */
	public static String getEmail(String memberid) {
		String sql = "select Email from members where MemberID='" + memberid + "'";
		String key = "Email";
		String email = (String) getDBObject(sql, key);
		return email;
	}
	
	/**
	 * 获取指定手机号码的最新验证码
	 * 
	 * @param mobile
	 * @return
	 */
	public static String getVerifyCode(String mobile) {
		String sql = "select VerifyCode from member_verifys where IdentifyID=" + "'" + mobile + "' "
				+ "order by SendTime desc";
		String key = "VerifyCode";
		String code = (String) getDBObject(sql, key);
		return code;
	}

	/**
	 * 判断手机的验证码类型 '1：邮件激活验证码 2：手机绑定验证码 3:用户找回密码验证码
	 * 4:用户找回交易密码验证码;5:用户注册;6:账号保护;7:手机解绑;8:邮箱解绑;9:合并账号',10：快捷登录
	 * 
	 * @param mobile
	 *            手机号码
	 * @param type
	 *            期望的验证码类型
	 * @return
	 */
	public static boolean compareCodeType(String mobile, int type) {
		String sql = "select * from member_verifys where IdentifyID=" + "'" + mobile + "' " + "order by SendTime desc";
		String key = "VerifyType";
		int typedb = (int) getDBObject(sql, key);
		return type == typedb;
	}

	/**
	 * 从数据库中获取可用的邀请码
	 * 
	 * @return
	 */
	public static String getInviteCode() {
		String sql = "select InviteCode from invite_codes where IsUsable='1' order by CreateTime DESC";
		String key = "InviteCode";
		String code = (String) getDBObject(sql, key);
		return code;
	}

	/**
	 * 根据id从数据库中获取广告name
	 * 
	 * @param id
	 * @return
	 */
	public static String getAdModuleNameByID(String id) {
		String sql = "select Name from live_ad_modules where AdModuleID='" + id + "' order by CreateTime DESC";
		String key = "Name";
		String name = (String) getDBObject(sql, key);
		return name;
	}

	/**
	 * 根据alias从数据库中获取广告name
	 * 
	 * @param alias
	 * @return
	 */
	public static String getAdModuleNameByAlias(String alias) {
		String sql = "select Name from live_ad_modules where Alias='" + alias + "' order by CreateTime DESC";
		String key = "Name";
		String name = (String) getDBObject(sql, key);
		return name;
	}

	/**
	 * 从数据库中获取设备通知状态
	 * 
	 * @param id
	 * @return
	 */
	public static String getlogDeviceNotificationStatus(String id) {
		String sql = "select NotificationStatus from device_status where DeviceID='" + id + "'";
		String key1 = "NotificationStatus";
		String status = (String) getDBObject(sql, key1);
		return status;
	}

	/**
	 * 从数据库获取未回复的卖家id串
	 * 
	 * @param id
	 * @return
	 */
	public static String getnoAnswerChat(String id) {
		String sql = "select * from easemob_no_answer_chats where FromMemberID='" + id
				+ "' order by EasemobChatID desc";
		String key1 = "ToMemberID";
		String toMemberID = (String) getDBObject(sql, key1);
		return toMemberID;
	}

	/**
	 * 从数据库返回指定key的配置内容
	 * 
	 * @param key
	 * @return
	 */
	public static String getConfigContent(String key) {
		String sql = "select * from sys_configs where ConfigKey='" + key + "'";
		String key1 = "Content";
		String content = (String) getDBObject(sql, key1);
		return content;
	}

	/**
	 * 获取用户的最后登录时间
	 * 
	 * @param memberid
	 * @return
	 */
	public static Timestamp getLastLoginTime(String memberid) {
		String sql = "select * from members where MemberID='" + memberid + "'";
		String key1 = "LastLoginDate";
		Timestamp time = (Timestamp) getDBObject(sql, key1);
		return time;
	}

	public static void main(String[] args) {
		Timestamp a = getLastLoginTime("1536449");
		System.out.println(a);
	}
}
