package com.haimi.hm.data;

import org.testng.annotations.DataProvider;

/**
 * me
 * 
 * @author iris
 *
 */
public class MeData {

	/*
	 * 用戶信息
	 */
	@DataProvider(name = "profile")
	public static Object[][] profile() {
		return new Object[][] { { "13000000003", "qa1234", 1, "" }, { "", "", -100, "登录后才能继续操作" } };
	}

	/*
	 * 商品详情页，优惠券信息展示 productid：商品id 优惠券信息：信息文案，用于比较 登录用户：老用户，新用户 devicdid:新老设备
	 */
	@DataProvider(name = "ownInfo")
	public static Object[][] ownInfo() {
		return new Object[][] { { "", "", "4349663", "4349663", "94E9552F-8F88-4E61-B575-E54C1B73C156", 1, "" },
				{ "", "", "4080730", "4080730", "94E9552F-8F88-4E61-B575-E54C1B73C156", 1, "" },
				{ "", "", "4349663", "4349663", "94E9552F-7777-4E61-B575-E54C1B73C156", 1, "" },
				{ "13000000003", "qa1234", "4349663", "4349663", "94E9552F-8F88-4E61-B575-E54C1B73C156", 1, "" } };
	}

	// /*
	// * 收藏列表测试 type，page，pagesize
	// */
	// @DataProvider(name = "favorites")
	// public static Object[][] favorites() {
	// return new Object[][] { { "Mall", "1", "10" }, // 店铺
	// { "", "1000", "null" }, // 商品列表
	// { "null", "null", "null" }, // 商品列表
	// { "中文", "null", "1000" }, // 商品列表
	// { "1232", "1", "10" }, // 商品列表
	// { "", "", "" }, // 商品列表
	// { "null", "", "20" }, // 商品列表
	// { "中文", "1", "" }, // 商品列表
	// { "1232", "2", "10" } // 商品列表
	// };
	// }

	@DataProvider(name = "favorites")
	public static Object[][] favorites() {
		return new Object[][] { { "", "", "", "", "", "", -100, "登录后才能继续操作" },
				{ "13000000003", "qa1234", "20", "1", "N", "N", 1, "success" },
				{ "13000000003", "qa1234", "10", "1", "N", "N", 1, "success" } };
	}

	@DataProvider(name = "removeView")
	public static Object[][] removeView() {
		return new Object[][] { { "", "", "", "", -100, "登录后才能继续操作" },
				{ "13000000003", "qa1234", "37914657", "N", 1, "足迹删除成功" },
				{ "13000000003", "qa1234", "37064556,37914578,37914571", "N", 1, "足迹删除成功" },
				{ "13000000003", "qa1234", "", "Y", 1, "足迹删除成功" } };
	}

	@DataProvider(name = "buyerStatus")
	public static Object[][] buyerStatus() {
		return new Object[][] { { "13000000003", "qa1234", 1, "" }, { "", "", -100, "登录后才能继续操作" } };
	}

	@DataProvider(name = "viewLog")
	public static Object[][] viewLog() {
		return new Object[][] { { "13000000003", "qa1234", "20", "1", 1, "success" },
				{ "18056020694", "aaa123", "", "", 1, "success" }, { "", "", null, "", 1, "success" },
				{ "", "", "", null, 1, "success" } };
	}

	@DataProvider(name = "shareCredit")
	public static Object[][] shareCredit() {
		return new Object[][] { { "13000000003", "qa1234", 1, "分享成功" } };
	}

	@DataProvider(name = "getCreditDetail")
	public static Object[][] getCreditDetail() {
		return new Object[][] { { "13000000003", "qa1234", "10", "1", 1, "success" }, };
	}

	@DataProvider(name = "getlogininfo")
	public static Object[][] getlogininfo() {
		return new Object[][] { { "18056020694", "aaa123", 1, "" }, { "", "", -100, "登录后才能继续操作" } };
	}

}
