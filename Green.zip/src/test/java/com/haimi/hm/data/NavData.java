package com.haimi.hm.data;

import org.testng.annotations.DataProvider;

/**
 * nav
 * 
 * @author iris
 *
 */
public class NavData {

	/**
	 * 首页导航
	 * 
	 * @return
	 */
	@DataProvider(name = "list")
	public static Object[][] list() {
		return new Object[][] { { 1, "" } };
	}

	/**
	 * 导航页对应大家都在买商品分组列表
	 * 
	 * @return
	 */
	@DataProvider(name = "advertTeamProducts")
	public static Object[][] advertTeamProducts() {
		return new Object[][] { { "2", "20", "1", 1, "" }, { "99", "20", "1", 1, "" }, // 这个导航不存在，是否应该提醒？
				{ "null", "20", "1", -1, "未指定导航" }, { "", "20", "1", -1, "未指定导航" }, { null, "20", "1", -1, "未指定导航" },
				{ "wrong", "20", "1", -1, "未指定导航" }, { "中文", "20", "1", -1, "未指定导航" } };
	}
}
