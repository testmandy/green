package com.haimi.hm.data;

import org.testng.annotations.DataProvider;

import com.haimi.util.Tools;

/**
 * search
 * 
 * @author iris
 *
 */
public class SearchData {

	/**
	 * 热词
	 * 
	 * @return
	 */
	@DataProvider(name = "hotword")
	public static Object[][] hotword() {
		return new Object[][] { { "PRODUCT", 1, "" }, { "错误的输入", -1, "不支持的搜索类型" }, { "", 1, "" }, { "null", 1, "" },
				{ null, 1, "" } };
	}

	/**
	 * 建议
	 * 
	 * @return
	 */
	@DataProvider(name = "suggest")
	public static Object[][] suggest() {
		return new Object[][] { { "面", 1, "" }, { "", 1, "" }, { "null", 1, "" }, { null, 1, "" }, { "a", 1, "" } };
	}

	/**
	 * 商品
	 * 
	 * @return
	 */
	@DataProvider(name = "product")
	public static Object[][] product() {
		return new Object[][] {
				// 正常搜索
				{ Tools.getM("Deposited=N, pageSize=20, page=1, Promotion=N, CreditDeduct=N, Subject=网易严选,Sort=null"),
						1, "" },
				{ Tools.getM(
						"Deposited=N, pageSize=20, page=1, Promotion=N, CreditDeduct=N, Subject=网易严选,Sort=PriceAsc"), 1,
						"" },
				{ Tools.getM(
						"Deposited=Y, pageSize=20, page=1, Promotion=Y, CreditDeduct=Y, Subject=网易严选,Sort=PriceDesc"),
						1, "" },
				{ Tools.getM(
						"Deposited=N, pageSize=20, page=1, Promotion=Y, CreditDeduct=N, Subject=网易严选,Sort=PriceAsc"), 1,
						"" },
				{ Tools.getM(
						"Deposited=Y, pageSize=20, page=1, Promotion=N, CreditDeduct=N, Subject=网易严选,Sort=PriceDesc"),
						1, "" },
				{ Tools.getM(
						"Deposited=N, pageSize=20, page=1, Promotion=N, CreditDeduct=Y, Subject=网易严选,Sort=SoldNum"), 1,
						"" },
				// 筛选
				{ Tools.getM(
						"Deposited=N, pageSize=20, page=1, Promotion=N, CreditDeduct=Y, Subject=网易严选,Sort=SoldNum,Logis=FreeShipping,PriceMax=0,PriceMin=10"),
						1, "" },
				{ Tools.getM(
						"Deposited=N, pageSize=20, page=1, Promotion=Y, CreditDeduct=Y, Subject=网易严选,Sort=SoldNum,Logis=DIRECT,PriceMax=ww,PriceMin=0"),
						1, "" },
				{ Tools.getM(
						"Deposited=N, pageSize=20, page=1, Promotion=N, CreditDeduct=N, Subject=网易严选,Sort=SoldNum,Logis=FreeTax,PriceMax=10,PriceMin=0"),
						1, "" }, };
	}

}
