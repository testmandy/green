package com.haimi.hm.data;

import org.testng.annotations.DataProvider;

/**
 * 意见反馈测试数据
 * 
 * @author puff
 *
 */

public class FeedbackData {

	@DataProvider(name = "post")
	public static Object[][] post() {
		return new Object[][] { { "测试", "13000000003", "海蜜接口测试专用", 1, "提交成功" }, { "测试", "", "海蜜接口测试专用", 1, "提交成功" },
				{ "测试", "13000000003", "", 1, "提交成功" }, { "测试", "", "", 1, "提交成功" },
				{ "", "13000000003", "海蜜接口测试专用", -1, "反馈内容不能为空" } };
	}
}
