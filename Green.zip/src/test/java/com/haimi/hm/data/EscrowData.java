package com.haimi.hm.data;

import org.testng.annotations.DataProvider;

public class EscrowData {

	// @DataProvider(name = "detail")
	// public static Object[][] detail() {
	// return new Object[][] { { "526013", 1, "ok" } };
	// }

	@DataProvider(name = "create")
	public static Object[][] create() {
		return new Object[][] {
				// 正常下单
				{ "", "189.190.0,9.11.0", "", "true", "1", "4141390", "", "0", "171910", "", 1, "创建订单成功，请尽快支付。" },
				// 未填写收货地址
				{ "", "189.190.0,9.11.0", "", "true", "1", "4141390", "", "0", "", "", -1,
						"收货信息不存在或已被删除，请重新选择有效的收货信息。" } };
		// 未填写购买数量
		// { "", "189.190.0,9.11.0", "", "true", "", "4141390", "", "0", "",
		// "171910",-1, "数量不能少于1"}};
	}

	/*
	 * @DataProvider(name = "delete") public static Object[][] delete() { return
	 * new Object[][] { {"526104","139267837494009",1,"删除成功"} }; }
	 */

	/*
	 * @DataProvider(name = "cancel") public static Object[][] cancel() { return
	 * new Object[][] { { "526011", "我不想买了", 1, "订单已取消" } }; }
	 * 
	 * @DataProvider(name = "suggestProducts") public static Object[][]
	 * suggestProducts() { return new Object[][] { { "526013", 1, "" } }; }
	 */

	// @DataProvider(name = "payAllMerge")
	// public static Object[][] payAllMerge() {
	// return new Object[][] { { "", "0", "123456", "", "", "66.0", "526013",
	// "alipay-app", 1, "付款成功" } };
	// }

	// @DataProvider(name = "batchDetails")
	// public static Object[][] batchDetails() {
	// return new Object[][] { { "526013", 1, "" } };
	// }

	@DataProvider(name = "customInfo")
	public static Object[][] customInfo() {
		return new Object[][] { { "526013", 1, "" } };
	}

	@DataProvider(name = "buyerList")
	public static Object[][] buyerList() {
		return new Object[][] { { "", "20", "1", 1, "ok" } ,
			{ "WAIT_BUYER_PAYALL", "20", "1", 1, "ok" } ,//待付款
		{ "WAIT_SELLER_SHIP", "20", "1", 1, "ok" } ,//等待买手发货
		{ "WAIT_BUYER_TAKEOVER", "20", "1", 1, "ok" } ,//等待确认收货
		{ "TAKEOVER_ARGUE", "20", "1", 1, "ok" } ,//退款维权
		{ "TRANSACTION_COMPLETE", "20", "1", 1, "ok" } ,//交易成功
		{ "TRANSACTION_CANCEL", "20", "1", 1, "ok" } ,//交易关闭
		{ "SYSTEM_HELD", "20", "1", 1, "ok" } ,//系统冻结
		{ "WAIT_BUYER_REVIEW", "20", "1", 1, "ok" } ,//待评价订单
		
		
		};
	}
	
	
	
	@DataProvider(name = "getArgueAmountDetail")
	public static Object[][] getArgueAmountDetail() {
	return new Object[][] {
	{"69.00","526615","0",1,""}
	};
	}
	@DataProvider(name = "argueDetail")
	public static Object[][] argueDetail() {
	return new Object[][] {
	{"52193",1,"ok"}
	};
	}


	@DataProvider(name = "remindShip")
	public static Object[][] remindShip() {
	return new Object[][] {
	{"526615",1,"您已提醒卖家发货"}
	};
	}
	@DataProvider(name = "applyArgue")
	public static Object[][] applyArgue() {
	return new Object[][] {
	{"测试测试测试","卖家缺货","ONLY_MONEY","69.00","526615","N",1,"退款申请提交成功。"}
	};
	}
	@DataProvider(name = "cancelArgue")
	public static Object[][] cancelArgue() {
	return new Object[][] {
	{"526615","0",1,"您已撤销退款申请。"}
	};
	}
}
