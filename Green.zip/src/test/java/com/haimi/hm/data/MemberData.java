package com.haimi.hm.data;

import org.testng.annotations.DataProvider;

/**
 * 用户用例入参
 * 
 * @author iris
 *
 */
public class MemberData {

	/*
	 * 登录账号和密码 username,password,platform,deviceid,pushid, belongto,flag
	 */
	@DataProvider(name = "login")
	public static Object[][] login() {
		return new Object[][] { { "15012345678", "aaa123", "IOS", "null", "错误中文", "null", 1, "登录成功" }, // 正确的账号密码
				{ "null", "aaa123", "ANDROID", "null", "null", "HAIXIAO", -1, "登录账号不能为空" }, // null手机号码
				{ "", "aaa123", "ANDROID", "null", "null", "HAIXIAO", -1, "登录账号不能为空" }, // 空手机号码
				{ "15012345678", "null", "null", "我是中文", "null", "HAIXIAO", -1, "账号或密码有误，请核对后重新输入！" }, // null密码
				{ "15012345678", "", "null", "我是中文", "null", "HAIXIAO", -1, "请输入密码" }, // 空密码
				{ "haha哈", "ada123", "IOS", "null", "错误中文", "null", -1, "该手机号未注册，请使用快捷登录" }, // 错误的账号密码
				{ "15012345678", "aaa123", "ANDROID", "null", "1232323", "HAIMI", 1, "登录成功" },
				{ "15012345678", "aaa123", "IOS", "4234324wrewr", "错误中文", "xxxx", 1, "登录成功" },
				{ "15012345678", "aaa123", "null", "", "null", "HAIXIAO", 1, "登录成功" },
				{ "15012345678", "aaa123", "", "错误中文", "english", "", 1, "登录成功" },
				{ "15012345678", "aaa123", "中文平台", "111-111-111-111", "", "null", 1, "登录成功" } };
	}

	/*
	 * 发送快捷登录验证码 mobile,flag
	 */
	@DataProvider(name = "sendQuickLoginCode")
	public static Object[][] sendQuickLoginCode() {
		return new Object[][] { { "null", -1, "请输入有效的手机号码。" }, // null
				{ "", -1, "请输入有效的手机号码。" }, // 空
				{ null, -1, "请输入有效的手机号码。" }, // 空
				{ "000000000001", 1, "验证码发送成功。" }, // 正确位数的号码
				{ "中文字符", -1, "请输入有效的手机号码。" }, // 中文
				{ "1231546545464213123", 1, "验证码发送成功。" } // 格式不正确,发送快捷登录和发送注册的验证码在手机号码的校验上的规则不一致
		};
	}

	/*
	 * 发送手机注册验证码 mobile,flag
	 */
	@DataProvider(name = "sendRegisterMobileCode")
	public static Object[][] sendRegisterMobileCode() {
		return new Object[][] { { null, -1, "请输入有效的手机号码。" }, { "null", -1, "请输入有效的手机号码。" }, // null
				{ "", -1, "请输入有效的手机号码。" }, // 空
				{ "000000000001", -1, "请输入有效的手机号码。" }, // 正确位数的号码
				{ "中文字符", -1, "请输入有效的手机号码。" }, // 中文
				{ "13000000001", -2, "该手机已注册，请使用另外一个或请联系客服。" }, // 已经注册的手机号码
				{ "13000000099", 1, "验证码发送成功。" }, // 未注册的手机号码
				{ "1231546545464213123", -1, "请输入有效的手机号码。" } // 格式不正确
		};
	}

	/*
	 * 设置邮箱测试 email，flag
	 */
	@DataProvider(name = "setEmail")
	public static Object[][] setEmail() {
		return new Object[][] { { "中文english999", -1, "Email格式不正确" }, // 字符串型
				{ "null", -1, "数据不完整" }, // null的email
				{ "", -1, "数据不完整" }, // 空的email
				{ System.currentTimeMillis() + "@163.com", true, "操作成功" }, // 正常的email
				{ System.currentTimeMillis() + "中文@163.com", -1, "Email格式不正确" }, // 中文字符的email
				{ System.currentTimeMillis() + "@中文163.com", -1, "Email格式不正确" } // 后缀错误的email
		};
	}

	@DataProvider(name = "getEasemobPassword")
	public static Object[][] getEasemobPassword() {
		return new Object[][] { { "13000000003", "qa1234", 1, "获取成功" }, { "", "", -100, "登录后才能继续操作" } };
	}

	@DataProvider(name = "resetPassword")
	public static Object[][] resetPassword() {
		return new Object[][] { { "13000000003", "qa1234", "qa1234", "123456", -1, "密码6到20位，包含字母和数字" },
				{ "13000000003", "qa1234", "qa1234", "aa12", -1, "密码6-20位，包含字母和数字" },
				{ "13000000003", "qa1234", "qa1234", "", -1, "密码6-20位，包含字母和数字" },
				{ "13000000003", "qa1234", "qa1234", "aaa123", 1, "密码更新成功" },
				{ "", "", "", "aaa123", -100, "登录后才能继续操作" },
				{ "13000000003", "qa1234", "qa1234", "qa1234", -1, "新密码和旧密码一致" },
				{ "13000000003", "qa1234", "aaa123", "qa1234", -1, "原密码不匹配" },
				{ "13000000003", "qa1234", "", "", -1, "新密码和旧密码一致" } };
	}

//	@DataProvider(name = "setPassword")
//	public static Object[][] setPassword() {
//		return new Object[][] { { "12345678999", "aaa123", "aaa123", 1, "密码设置成功。" },
//				{ "12345678988", "aaa123", "123aaa", -1, "" }, { "12345678988", "aaa123", "", -1, "" },
//				{ "12345678988", "", "", -1, "" }, { "", "", "", -1, "密码不能为空。" },
//				{ "12345678988", "aaa12", "aaa12", -1, "" }, { "12345678988", "123456", "123456", -1, "" } };
//	}

	@DataProvider(name = "sendMergeAccountCode")
	public static Object[][] sendMergeAccountCode() {
		return new Object[][] { { "13245678952", -1, "您已绑定过该手机,请不要重复绑定" }, { "", -1, "请输入有效的手机号码。" },
				{ "null", -1, "请输入有效的手机号码。" }, { null, -1, "请输入有效的手机号码。" }, { "12345678977", 1, "验证码发送成功。" } };
	}

	@DataProvider(name = "resetRefundPassword")
	public static Object[][] resetRefundPassword() {
		return new Object[][] { { "18056020694", "aaa123", "121212", "123456", 1, "支付密码设置成功" },
				{ "18056020694", "aaa123", "1212", "123456", -1, "原密码不匹配" },
				{ "18056020694", "aaa123", "", "123456", -1, "原密码不匹配" },
				{ "18056020694", "aaa123", "null", "123456", -1, "原密码不匹配" },
				{ "18056020694", "aaa123", null, "123456", -1, "原密码不匹配" },
				{ "18056020694", "aaa123", "121212", "1212", -1, "新支付密码必须为6位数字" },
				{ "18056020694", "aaa123", "121212", "", -1, "新支付密码必须为6位数字" },
				{ "18056020694", "aaa123", "121212", "null", -1, "新支付密码必须为6位数字" },
				{ "", "", "121212", "123456", -100, "登录后才能继续操作" }};
	}
}
