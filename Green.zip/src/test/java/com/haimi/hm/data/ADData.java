package com.haimi.hm.data;

import org.testng.annotations.DataProvider;

/**
 * 广告测试用例数据
 * 
 * @author iris
 *
 */
public class ADData {

	/*
	 * 获取一个广告位所包含的所有模块信息 alias:必填，广告位别名 date：时间 belongto：haimi，haixiao
	 * scene：场景，newcomer会显示新人礼
	 */
	@DataProvider(name = "adModuleGet")
	public static Object[][] adModuleGet() {
		return new Object[][] { 
			{ "index_2", "null", "null", "null", "null", 1, "" },
			{ "discover", null, null, null, null, 1, "" },
			{ "yanxuan-cat-list", "", "", "", "", 1, "" },
			{ "null", "null", "null", "null", "null", -1, "未指定广告位" },
			{ "", "", "", "", "", -1, "未指定广告位" },
			{ null, null, null, null, null, -1, "未指定广告位" },
			{ "中文", "", "", "", "", -1, "" }, //不存在的广告位指定，应该报错的，现在返回1
			{ "null", "11111", "null", "null", "null", -1, "未指定广告位" },
			{ null, "121", "null", "null", "null", 1, "" },
			{ "", "158", "null", "null", "null", 1, "" }, 
			{ "discover", "158", "null", "null", "null", 1, "" },
			{ "discover", "null", "1970-01-01 00:00:00", "haimi", "Newcomer", 1, "" }, 
			{ "discover", "null", "null", "haixiao", "新人礼", -1, "" }, //scene使用了错误的参数，广告模块的data数据为空
			{ "discover", "null", "2017-02-01 10:10:17", "海蜜", "Newcomer", -1, "" }, //平台设置了非格式化文字，广告模块的data数据为空
			{ "discover", "null", "2017-02-01 10:10:17", "haimi", "Newcomer", 1, "" },
			{ "discover", "null", "9999-02-01", "haimi", "Newcomer", -1, "" }, //错误的时间格式，广告模块的data数据为空
			{ "discover", "null", "时间", "haimi", "Newcomer", 1, "" } //时间设置使用非时间格式，SQLSTATE[HY000]: General error: 1271 Illegal mix of collations for operation '<=' expected [1] but found [-1]
		};
	}
		
	/**
	 * 获取个性化广告位所包含的所有模块信息
	 * 
	 * @return
	 */
	@DataProvider(name = "adModuleDynamic")
	public static Object[][] adModuleDynamic() {
		return new Object[][] { { "index_2", "null", "null", "null", 1, "" }, { "discover", null, null, null, 1, "" },
				{ "yanxuan-cat-list", "", "", "", 1, "" },

				{ "null", "null", "null", "null", -1, "未指定广告位" }, { "", "", "", "", -1, "未指定广告位" },
				{ null, null, null, null, -1, "未指定广告位" }, { "中文", "", "", "", -1, "" }, // 以上4条不存在的广告位指定，应该报错的，现在返回1，同时注意这个接口现在不在用，所以数据返回都是空的
		};
	}

}
