package com.haimi.hm.data;

import org.testng.annotations.DataProvider;

/**
 * 收藏测试用例数据
 * 
 * @author puff
 *
 */

public class FavoriteData {

	@DataProvider(name = "product")
	public static Object[][] product() {
		return new Object[][] { { "13000000003", "qa1234", "189.190.0,9.11.0", "4286309", 1, "收藏成功" },
				{ "13000000003", "qa1234", "null", "4286309", 1, "收藏成功" },
				{ "13000000003", "qa1234", null, "4286309", 1, "收藏成功" },
				{ "13000000003", "qa1234", " ", "4286309", 1, "收藏成功" },
				{ "13000000003", "qa1234", "189.190.0,9.11.0", "", -1, "商品ID不能为空" },
				{ "13000000003", "qa1234", "189.190.0,9.11.0", "null", -1, "商品ID不能为空" } };
	}

	@DataProvider(name = "productCancel")
	public static Object[][] productCancel() {
		return new Object[][] { { "13000000003", "qa1234", "4286309", 1, "取消收藏宝贝成功" },
				{ "13000000003", "qa1234", "", -1, "未指定商品ID" }, { "13000000003", "qa1234", "null", -1, "未指定商品ID" },
				{ "13000000003", "qa1234", null, -1, "未指定商品ID" }, {"", "", "4286309", 1, "取消收藏宝贝成功"} };
	}
}
