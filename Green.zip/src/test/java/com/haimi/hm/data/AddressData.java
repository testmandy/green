package com.haimi.hm.data;

import org.testng.annotations.DataProvider;

import com.haimi.util.Tools;

/**
 * address
 * 
 * @author iris
 *
 */
public class AddressData {

	/**
	 * 列表
	 * 
	 * @return
	 */
	@DataProvider(name = "list")
	public static Object[][] list() {
		return new Object[][] { { "", 1, "success" }, { "null", 1, "success" }, { null, 1, "success" },
				{ "N", 1, "success" }, { "Y", 1, "success" }, { "wrong", 1, "success" } // isdefault的字段应该已经废弃了
		};
	}

	/**
	 * 添加新的地址
	 * 
	 * @return
	 */
	@DataProvider(name = "add")
	public static Object[][] add() {
		return new Object[][] {
				// 是否默认和邮编非填写项目,目前也不用了，故不用组合测试了
				{ "null", "东城区", "13000000003", "null", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), 1, "添加地址成功" },
				{ "", "东城区", "13000000003", "", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), 1, "添加地址成功" },
				{ null, "东城区", "13000000003", null, "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), 1, "添加地址成功" },
				{ "N", "东城区", "13000000003", "310052", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), 1, "添加地址成功" },
				{ "Y", "东城区", "13000000003", "wrong", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), 1, "添加地址成功" },
				{ "wrong", "东城区", "13000000003", "12345678901234567890", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), 1, "添加地址成功" },
				// 手机号码格式验证
				{ "null", "东城区", "130000003", "null", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), -1, "手机号码格式不正确" },
				{ "null", "东城区", "错误的电话号码", "null", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), -1, "手机号码格式不正确" },
				{ "null", "东城区", "", "null", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市", Tools.getRandomString(5),
						-1, "手机号码不能为空" },
				{ "null", "东城区", "null", "null", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), -1, "手机号码不能为空" },
				{ "null", "东城区", null, "null", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市", Tools.getRandomString(5),
						-1, "手机号码不能为空" },
				// 详细地址验证
				{ "null", "东城区", "13000000003", "null", "北京市", "", "北京市", Tools.getRandomString(5), -1, "地址信息不完整" },
				{ "null", "东城区", "13000000003", "null", "北京市", "null", "北京市", Tools.getRandomString(5), -1, "地址信息不完整" },
				{ "null", "东城区", "13000000003", "null", "北京市", null, "北京市", Tools.getRandomString(5), -1, "地址信息不完整" },
				// 省市区验证
				{ "null", "null", "13000000003", "null", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), 1, "添加地址成功" },
				{ "null", "", "13000000003", "null", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), 1, "添加地址成功" },
				{ "null", null, "13000000003", "null", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), 1, "添加地址成功" },
				{ "null", "错误的区", "13000000003", "null", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), 1, "添加地址成功" },
				{ "null", "东城区", "13000000003", "null", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "",
						Tools.getRandomString(5), -1, "地址信息不完整" },
				{ "null", "东城区", "13000000003", "null", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "null",
						Tools.getRandomString(5), -1, "地址信息不完整" },
				{ "null", "东城区", "13000000003", "null", "北京市", "这里是详细地址" + Tools.getTimeStamp(), null,
						Tools.getRandomString(5), -1, "地址信息不完整" },
				{ "null", "东城区", "13000000003", "null", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "错误的省或市",
						Tools.getRandomString(5), 1, "添加地址成功" } };
	}

}
