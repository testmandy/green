package com.haimi.hm.data;

import org.testng.annotations.DataProvider;

/**
 * invite
 * 
 * @author iris
 *
 */
public class InviteData {

	/*
	 * 邀请码测试 memberid，flag，nickname
	 */
	@DataProvider(name = "presentGet")
	public static Object[][] presentGet() {
		return new Object[][] { { "null", -1, "未指定用户" }, // null的memberid
				{ "", -1, "未指定用户" }, // 空的memberid
				{ null, -1, "未指定用户" }, // 空的memberid
				{ "中文字符", 1, "" }, // 中文字符，不存在的id不应该产生邀请码，但是现在还是会产生
				{ "999999999", 1, "" }, // 不存在的memberid
				{ "1536449", 1, "" }// 正确的memberid
		};
	}

	@DataProvider(name = "index")
	public static Object[][] index() {
		return new Object[][] { { 1, "成功" } };
	}

	@DataProvider(name = "receive")
	public static Object[][] receive() {
		return new Object[][] { { "zbsjq", 1, "恭喜你获得一张10元红包" }, { "zbsjq", -1, "抱歉，你已经兑换过此类邀请码" },
				{ "1234", -1, "抱歉，您输入的邀请码不存在" } };
	}

}
