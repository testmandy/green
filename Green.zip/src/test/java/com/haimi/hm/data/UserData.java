package com.haimi.hm.data;

import org.testng.annotations.DataProvider;

/**
 * 
 * @author iris
 *
 */
public class UserData {

	/**
	 * 每日签到列表 这个两个接口都存在返回的json串中，在开头位置为空格的情况
	 * 
	 * @return
	 */
	@DataProvider(name = "signInfo")
	public static Object[][] signInfo() {
		return new Object[][] { { 1, "" } };
	}

	/**
	 * 签到
	 * 
	 * @return
	 */
	@DataProvider(name = "signSign")
	public static Object[][] signSign() {
		return new Object[][] { { 1, "签到成功" } };
	}
}
