package com.haimi.hm.data;

import org.testng.annotations.DataProvider;

/**
 * 消息测试用例数据
 * 
 * @author iris
 *
 */
public class EasemobData {

	/*
	 * 优惠虚拟消息，仅发送给新设备 deviceid newflag：1，新设备，0，不是新设备
	 */
	@DataProvider(name = "easemobGetVirtualBonusMessage")
	public static Object[][] easemobGetVirtualBonusMessage() {
		return new Object[][] { { "94E9552F-8F88-4E61-B575-E54C1B73C156", 0, 1, "" },
				{ "37491153423432432456855", 1, 1, "" } };
	}

}
