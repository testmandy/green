package com.haimi.hm.data;

import org.testng.annotations.DataProvider;

import com.haimi.util.Tools;

/**
 * 系统用例入参
 * 
 * @author iris
 *
 */
public class SystemData {

	/*
	 * 美拍链接视频解析 接口：/system/get-meipai-video-url url：为美拍链接，空，不存在的链接
	 * 返回：正确的视频链接，错误的返回
	 */
	@DataProvider(name = "getMeipaiVideoUrl")
	public static Object[][] getMeipaiVideoUrl() {
		return new Object[][] { { "null", -1, "Url不能为空" }, { "", -1, "Url不能为空" }, { null, -1, "Url不能为空" },
				{ "http://www.meipai.com/media/637279763", 1, "success" }, // 现在的解析链接不对，没有以mp4结尾，app中也无法显示
				{ "http://www.meipai.com/media/1dsafsdfdssdf11111", -1, "获取视频链接失败" } };
	}

	/*
	 * 获取系统配置 接口：/system/get-config
	 */
	@DataProvider(name = "getConfig")
	public static Object[][] getConfig() {
		return new Object[][] { { "", "N", 1, "" }, { "null", "Y", 1, "" }, { null, "N", 1, "" },
				{ "CartNotice", "Y", 1, "" }, { "我是错误的key", "Y", 1, "" }, { "CartNotice,SignPicture,", "N", 1, "" },
				{ "Im wrong,SignPicture,", "Y", 1, "" } };
	}

	/*
	 * 未回复会话信息记录 tomemberid:空，自己的id，正确的id，不存在的id flag:-1,1
	 * 
	 */
	@DataProvider(name = "noAnswerChat")
	public static Object[][] noAnswerChat() {
		return new Object[][] { { "null", -1, "数据格式异常" }, { "", -1, "数据格式异常" }, { null, -1, "数据格式异常" },
				{ Tools.getRandomNum(5), 1, "" },
				{ Tools.getRandomNum(5) + "," + Tools.getRandomNum(5) + "," + Tools.getRandomNum(5), 1, "" },
				{ Tools.getRandomNum(5) + "." + Tools.getRandomNum(5) + "." + Tools.getRandomNum(5), -1, "数据格式异常" },
				{ "哈哈哈哈非", -1, "数据格式异常" } };
	}

	/*
	 * 记录用户设备是否开启通知 通知状态：Y，N，空，非格式化 设备id：空，id，中文 flag：1，-1
	 */
	@DataProvider(name = "logDeviceNotificationStatus")
	public static Object[][] logDeviceNotificationStatus() {
		return new Object[][] { { "N", "null", -1, "设备ID不能为空" }, { "N", "", -1, "设备ID不能为空" },
				{ "N", null, -1, "设备ID不能为空" }, { "null", "23432432434", 1, "" }, { "", "23432432434", 1, "" },
				{ null, "23432432434", 1, "" }, { "Y", "23432432434", 1, "" }, { "N", "23432432434", 1, "" },
				{ "y", "我是中文", 1, "" }, { "Y", "我是中文", 1, "" }, { "我是中文的通知状态", "我是中文", 1, "" } };
	}

	/**
	 * 获取系统配置信息，只有海蜜的联系和微信号
	 * 
	 * @return
	 */
	@DataProvider(name = "getSettingInfo")
	public static Object[][] getSettingInfo() {
		return new Object[][] { { 1, "" } };
	}

	/**
	 * 获取系统时间
	 * 
	 * @return
	 */
	@DataProvider(name = "getTime")
	public static Object[][] getTime() {
		return new Object[][] { { 1, "" } };
	}

	/**
	 * 客户端是否要上传crash日志
	 * 
	 * @return
	 */
	@DataProvider(name = "isUploadCrashLog")
	public static Object[][] isUploadCrashLog() {
		return new Object[][] { { 1, "" } };
	}

	/**
	 * 获取api服务器列表
	 * 
	 * @return
	 */
	@DataProvider(name = "apiPorts")
	public static Object[][] apiPorts() {
		return new Object[][] { { 1, "" } };
	}

	/**
	 * app是否需要升级
	 * 
	 * @return
	 */
	@DataProvider(name = "appUpdate")
	public static Object[][] appUpdateCdn() {
		return new Object[][] { { "", 1, "success" }, { "null", 1, "success" }, { null, 1, "success" },
				{ "ios", 1, "success" }, { "android", 1, "success" }, { "中文错误输入", 1, "success" } };
	}

	/**
	 * ping服务器
	 * 
	 * @return
	 */
	@DataProvider(name = "ping")
	public static Object[][] ping() {
		return new Object[][] { { 1, "" } };
	}

	/**
	 * 保存最后登录时间
	 * 
	 * @return
	 */
	@DataProvider(name = "saveLoginTime")
	public static Object[][] saveLoginTime() {
		return new Object[][] { { 1, "" } };
	}

	/**
	 * 获取应用启动图。存在多个取第一个。
	 * 
	 * @return
	 */
	@DataProvider(name = "startupImages")
	public static Object[][] startupImages() {
		return new Object[][] { { "", 1, "" }, { "null", 1, "" }, { null, 1, "" }, { "haimi", 1, "" },
				{ "wrong", 1, "" }, { "我是中文", 1, "" } };
	}

	/**
	 * /system/get-extra-app-info
	 * 
	 * @return
	 */
	@DataProvider(name = "getExtraAppInfo")
	public static Object[][] getExtraAppInfo() {
		return new Object[][] { { "", 1, "success" }, { "null", 1, "success" }, { null, 1, "success" },
				{ "ios", 1, "success" }, { "wrong", 1, "success" }, { "我是中文", 1, "success" },
				{ "android", 1, "success" }// 参数android报签名失败？其他参数返回始终是data中为空的
		};
	}

	@DataProvider(name = "getBrands")
	public static Object[][] getBrands() {
		return new Object[][] { { "Y", "null", 1, "" }, { "N", "null", 1, "" }, { "ALL", "null", 1, "" },
				{ "错误中文", "null", 1, "" }, { "ALL", "网易严选", 1, "" }, { "ALL", "", 1, "" }, { "ALL", null, 1, "" },
				{ "ALL", "不存在品牌", 1, "" }// 这里的参数key似乎没什么作用，YNALL现在的返回也没有区别统一了？
		};
	}

	@DataProvider(name = "faq")
	public static Object[][] faq() {
		return new Object[][] { { "18", 1, "" }, { "19", 1, "" }, { "20", 1, "" }, { "", 1, "" }, { "null", 1, "" },
				{ null, 1, "" }// 若传入的id不对，返回空字符串的1是否不应该，而是一定的提示？
		};
	}

	@DataProvider(name = "getRefundReason")
	public static Object[][] getRefundReason() {
		return new Object[][] { { "Y", 1, "" }, { "N", 1, "" }, { "U", 1, "" }, { "", 1, "" }, { "null", 1, "" },
				{ null, 1, "" }, { "中文", 1, "" } };
	}

	@DataProvider(name = "getRecommendProducts")
	public static Object[][] getRecommendProducts() {
		return new Object[][] { { 1, "" } // 500错误
		};
	}

	@DataProvider(name = "getRecommend")
	public static Object[][] getRecommend() {
		return new Object[][] { { "1", "20", 1, "" } // data 数据整体为空
		};
	}

}
