package com.haimi.hm.page;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;

import com.haimi.helper.HttpClientHelper;
import com.haimi.r.R;
import com.haimi.util.ParamsWorker;

import net.sf.json.JSONObject;

/**
 * Me
 * 
 * @author iris
 *
 */
public class Me extends BasePage {

	public Me(CookieStore cookie) {
		super(cookie);
	}

	/**
	 * 获取用户信息 必须登录 3.7.0修改返回
	 */
	public JSONObject profile() {
		// 拼接url
		String url = R.BASEURL + R.ME_PROFILE;

		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, cookie);

		return response;
	}

	/**
	 * 用户是否关注的列表或是否收藏的列表（待补充）。4.0.0修改
	 * 
	 * @param CheckMembersIsFollowed
	 * @param CheckProductsIsLiked
	 * @param CheckMallsIsLiked
	 * @param BelongTo
	 * @param checkProductPromotion
	 * @return
	 */
	public JSONObject ownInfo(String CheckProductsIsLiked, String checkProductPromotion, String CheckMembersIsFollowed,
			String CheckMallsIsLiked, String BelongTo) {
		String url = R.BASEURL + R.ME_OWN_INFO;

		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "CheckMembersIsFollowed", CheckMembersIsFollowed);
		ParamsWorker.addParams(params, "CheckProductsIsLiked", CheckProductsIsLiked);
		ParamsWorker.addParams(params, "CheckMallsIsLiked", CheckMallsIsLiked);
		ParamsWorker.addParams(params, "checkProductPromotion", checkProductPromotion);
		ParamsWorker.addParams(params, "BelongTo", BelongTo);

		JSONObject res = HttpClientHelper.get(url, params, cookie);

		return res;
	}

	// /**
	// * 获取收藏api
	// *
	// * @param type
	// * @param page
	// * @param pagesize
	// */
	// public JSONObject favorites(String type, String page, String pagesize) {
	// // 拼接url
	// String url = R.BASEURL + R.ME_FAVORITES;
	//
	// // 拼接传递的参数
	// List<NameValuePair> params = new ArrayList<NameValuePair>();
	// ParamsWorker.addParams(params, "Type", type);
	// ParamsWorker.addParams(params, "page", page);
	// ParamsWorker.addParams(params, "pageSize", pagesize);
	//
	// // 执行请求，并获取请求返回
	// JSONObject response = HttpClientHelper.post(url, params, cookie);
	//
	// return response;
	// }

	public JSONObject favorites(String pageSize, String page, String MarkDown, String Disabled) {
		// 拼接url
		String url = R.BASEURL + R.ME_FAVORITES;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "pageSize", pageSize);
		ParamsWorker.addParams(params, "page", page);
		ParamsWorker.addParams(params, "MarkDown", MarkDown);
		ParamsWorker.addParams(params, "Disabled", Disabled);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject removeView(String ViewIDs, String RemoveAll) {
		// 拼接url
		String url = R.BASEURL + R.ME_REMOVE_VIEW;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "ViewIDs", ViewIDs);
		ParamsWorker.addParams(params, "RemoveAll", RemoveAll);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject buyerStatus(String SaleType, String BelongTo) {
		// 拼接url
		String url = R.BASEURL + R.ME_BUYER_STATUS;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "SaleType", SaleType);
		ParamsWorker.addParams(params, "BelongTo", BelongTo);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject viewLog(String pageSize, String page) {
		// 拼接url
		String url = R.BASEURL + R.ME_VIEW_LOG;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "pageSize", pageSize);
		ParamsWorker.addParams(params, "page", page);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject shareCredit(String type) {
		// 拼接url
		String url = R.BASEURL + R.ME_SHARE_CREDIT;
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "Type", type);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, cookie);
		return response;
	}

	public JSONObject getCreditDetail(String pageSize, String page) {
		// 拼接url
		String url = R.BASEURL + R.ME_GET_CREDIT_DETAIL;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "pageSize", pageSize);
		ParamsWorker.addParams(params, "page", page);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject getlogininfo() {
		String url = R.BASEURL + R.ME_GET_LOGIN_INFO;
		JSONObject response = HttpClientHelper.post(url, cookie);
		return response;
	}

}
