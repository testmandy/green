package com.haimi.hm.page;

import org.apache.http.client.CookieStore;

import com.haimi.helper.HttpClientHelper;
import com.haimi.r.R;
import net.sf.json.JSONObject;

/**
 * user-sign
 * 
 * @author iris
 *
 */
public class User extends BasePage {

	public User(CookieStore cookie) {
		super(cookie);
	}

	/**
	 * 每日签到列表
	 * 
	 */
	public JSONObject signInfo() {
		// 拼接url
		String url = R.BASEURL + R.USER_SIGN_INFO;

		JSONObject response = HttpClientHelper.get(url, cookie);

		return response;
	}

	/**
	 * 签到
	 * 
	 * @return
	 */
	public JSONObject signSign() {
		// 拼接url
		String url = R.BASEURL + R.USER_SIGN_SIGN;

		JSONObject response = HttpClientHelper.post(url, cookie);

		return response;
	}

}
