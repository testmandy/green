package com.haimi.hm.page;

import java.util.ArrayList;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;
import com.haimi.helper.HttpClientHelper;
import com.haimi.r.R;
import com.haimi.util.ParamsWorker;
import net.sf.json.JSONObject;

/**
 * 收藏
 * @author puff
 *
 */

public class Favorite extends BasePage {

	public Favorite(CookieStore cookie) {
		super(cookie);
	}

	public JSONObject product(String HmSource, String ProductID) {
		// 拼接url
		String url = R.BASEURL + R.FAVORITE_PRODUCT;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "Hm_Source", HmSource);
		ParamsWorker.addParams(params, "ProductID", ProductID);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject productCancel(String ProductID) {
		// 拼接url
		String url = R.BASEURL + R.FAVORITE_PRODUCT_CANCEL;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "ProductID", ProductID);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}
}
