package com.haimi.hm.page;

import org.apache.http.client.CookieStore;

/**
 * 功能基类,提供公共cookie
 * 
 * @author iris
 *
 */
public class BasePage {

	protected CookieStore cookie;

	public BasePage(CookieStore cookie) {
		this.cookie = cookie;
	}
}
