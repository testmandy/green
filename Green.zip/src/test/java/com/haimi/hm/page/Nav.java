package com.haimi.hm.page;

import java.util.ArrayList;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;
import com.haimi.helper.HttpClientHelper;
import com.haimi.r.R;
import com.haimi.util.ParamsWorker;
import net.sf.json.JSONObject;

/**
 * nav
 * 
 * @author iris
 *
 */
public class Nav extends BasePage {

	public Nav(CookieStore cookie) {
		super(cookie);
	}

	/**
	 * 首页导航
	 * 
	 * @return
	 */
	public JSONObject list() {
		// 拼接url
		String url = R.BASEURL + R.NAV_LIST;
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.get(url, cookie);
		return response;
	}

	/**
	 * 导航页对应大家都在买商品分组列表
	 * 
	 * @param NavID
	 * @param pageSize
	 * @param page
	 * @return
	 */
	public JSONObject advertTeamProducts(String NavID, String pageSize, String page) {
		// 拼接url
		String url = R.BASEURL + R.NAV_ADVERT_TEAM_PRODUCTS;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "NavID", NavID);
		ParamsWorker.addParams(params, "pageSize", pageSize);
		ParamsWorker.addParams(params, "page", page);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.get(url, params, cookie);
		return response;
	}
}
