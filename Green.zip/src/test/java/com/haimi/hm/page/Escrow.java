package com.haimi.hm.page;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;

import com.haimi.helper.HttpClientHelper;
import com.haimi.r.R;
import com.haimi.util.ParamsWorker;

import net.sf.json.JSONObject;

public class Escrow extends BasePage {

	public Escrow(CookieStore cookie) {
		super(cookie);
	}

	public JSONObject detail(String EscrowID) {
		// ƴ��url
		String url = R.BASEURL + R.ESCROW_DETAIL;
		// ƴ�Ӵ��ݵĲ���
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "EscrowID", EscrowID);
		// ִ�����󣬲���ȡ���󷵻�
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject create(String BuyerNote, String Hm_Source, String Coupon, String Follow, String Num,
			String ProductID, String Specific, String SkuID, String AddressID, String IdcardCode) {
		// ƴ��url
		String url = R.BASEURL + R.ESCROW_CREATE;
		// ƴ�Ӵ��ݵĲ���
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "BuyerNote", BuyerNote);
		ParamsWorker.addParams(params, "Hm_Source", Hm_Source);
		ParamsWorker.addParams(params, "Coupon", Coupon);
		ParamsWorker.addParams(params, "Follow", Follow);
		ParamsWorker.addParams(params, "Num", Num);
		ParamsWorker.addParams(params, "ProductID", ProductID);
		ParamsWorker.addParams(params, "Specific", Specific);
		ParamsWorker.addParams(params, "SkuID", SkuID);
		ParamsWorker.addParams(params, "AddressID", AddressID);
		ParamsWorker.addParams(params, "IdcardCode", IdcardCode);
		// ִ�����󣬲���ȡ���󷵻�
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject cancel(String EscrowID, String Reason) {
		// ƴ��url
		String url = R.BASEURL + R.ESCROW_CANCEL;
		// ƴ�Ӵ��ݵĲ���
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "EscrowID", EscrowID);
		ParamsWorker.addParams(params, "Reason", Reason);
		// ִ�����󣬲���ȡ���󷵻�
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject suggestProducts(String EscrowIDs) {
		// ƴ��url
		String url = R.BASEURL + R.ESCROW_SUGGEST_PRODUCTS;
		// ƴ�Ӵ��ݵĲ���
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "EscrowIDs", EscrowIDs);
		// ִ�����󣬲���ȡ���󷵻�
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject payAllMerge(String Coupon, String Credit, String RefundPassword, String Bonus, String Code,
			String Balance, String EscrowIDs, String Via) {
		// ƴ��url
		String url = R.BASEURL + R.ESCROW_PAY_ALL_MERGE;
		// ƴ�Ӵ��ݵĲ���
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "Coupon", Coupon);
		ParamsWorker.addParams(params, "Credit", Credit);
		ParamsWorker.addParams(params, "RefundPassword", RefundPassword);
		ParamsWorker.addParams(params, "Bonus", Bonus);
		ParamsWorker.addParams(params, "Code", Code);
		ParamsWorker.addParams(params, "Balance", Balance);
		ParamsWorker.addParams(params, "EscrowIDs", EscrowIDs);
		ParamsWorker.addParams(params, "Via", Via);
		// ִ�����󣬲���ȡ���󷵻�
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject batchDetails(String EscrowIDs) {
		// ƴ��url
		String url = R.BASEURL + R.ESCROW_BATCH_DETAILS;
		// ƴ�Ӵ��ݵĲ���
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "EscrowIDs", EscrowIDs);
		// ִ�����󣬲���ȡ���󷵻�
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject customInfo(String EscrowID) {
		// ƴ��url
		String url = R.BASEURL + R.ESCROW_CUSTOM_INFO;
		// ƴ�Ӵ��ݵĲ���
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "EscrowID", EscrowID);
		// ִ�����󣬲���ȡ���󷵻�
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}
	public JSONObject delete(String EscrowID,String OrderNO) {
		// ƴ��url
		String url = R.BASEURL + R.ESCROW_DELETE;
		// ƴ�Ӵ��ݵĲ���
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "EscrowID",EscrowID);
		ParamsWorker.addParams(params, "OrderNO",OrderNO);
		// ִ�����󣬲���ȡ���󷵻�
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
		}
	
	public JSONObject buyerList(String Status,String pageSize,String page) {
		// ƴ��url
		String url = R.BASEURL + R.ESCROW_BUYER_LIST;
		// ƴ�Ӵ��ݵĲ���
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "Status",Status);
		ParamsWorker.addParams(params, "pageSize",pageSize);
		ParamsWorker.addParams(params, "page",page);
		// ִ�����󣬲���ȡ���󷵻�
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
		}
	
	public JSONObject remindShip(String EscrowID) {
		// 拼接url
		String url = R.BASEURL + R.ESCROW_REMIND_SHIP;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "EscrowID",EscrowID);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
		}
	
	public JSONObject applyArgue(String BuyerNote,String BuyerReason,String ArgueType,String Amount,String EscrowID,String IsTakeover) {
		// 拼接url
		String url = R.BASEURL + R.ESCROW_APPLY_ARGUE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "BuyerNote",BuyerNote);
		ParamsWorker.addParams(params, "BuyerReason",BuyerReason);
		ParamsWorker.addParams(params, "ArgueType",ArgueType);
		ParamsWorker.addParams(params, "Amount",Amount);
		ParamsWorker.addParams(params, "EscrowID",EscrowID);
		ParamsWorker.addParams(params, "IsTakeover",IsTakeover);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
		}


	public JSONObject getArgueAmountDetail(String Amount,String EscrowID,String SkuID) {
		// 拼接url
		String url = R.BASEURL + R.ESCROW_GET_ARGUE_AMOUNT_DETAIL;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "Amount",Amount);
		ParamsWorker.addParams(params, "EscrowID",EscrowID);
		ParamsWorker.addParams(params, "SkuID",SkuID);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
		}
	
	
	public JSONObject argueDetail(String ArgueID) {
		// 拼接url
		String url = R.BASEURL + R.ESCROW_ARGUE_DETAIL;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "ArgueID",ArgueID);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
		}
	
	public JSONObject cancelArgue(String EscrowID,String SkuID) {
		// 拼接url
		String url = R.BASEURL + R.ESCROW_CANCEL_ARGUE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "EscrowID",EscrowID);
		ParamsWorker.addParams(params, "SkuID",SkuID);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
		}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
