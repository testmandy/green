package com.haimi.hm.page;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;

import com.haimi.helper.HttpClientHelper;
import com.haimi.r.R;
import com.haimi.util.ParamsWorker;

import net.sf.json.JSONObject;

/**
 * address
 * 
 * @author iris
 *
 */
public class Address extends BasePage {

	public Address(CookieStore cookie) {
		super(cookie);
	}

	/**
	 * 删除一条收货地址
	 * 
	 * @param AddressID
	 * @return
	 */
	public JSONObject delete(String AddressID) {
		// 拼接url
		String url = R.BASEURL + R.ADDRESS_DELETE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "AddressID", AddressID);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 获取收货地址列表
	 * 
	 * @param IsDefault
	 * @return
	 */
	public JSONObject list(String IsDefault) {
		// 拼接url
		String url = R.BASEURL + R.ADDRESS_LIST;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "IsDefault", IsDefault);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 添加一条收货地址
	 * 
	 * @param IsDefault
	 * @param Area
	 * @param Phone
	 * @param Zipcode
	 * @param City
	 * @param Detail
	 * @param Province
	 * @param Name
	 * @return
	 */
	public JSONObject add(String IsDefault, String Area, String Phone, String Zipcode, String City, String Detail,
			String Province, String Name) {
		// 拼接url
		String url = R.BASEURL + R.ADDRESS_ADD;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "IsDefault", IsDefault);
		ParamsWorker.addParams(params, "Area", Area);
		ParamsWorker.addParams(params, "Phone", Phone);
		ParamsWorker.addParams(params, "Zipcode", Zipcode);
		ParamsWorker.addParams(params, "City", City);
		ParamsWorker.addParams(params, "Detail", Detail);
		ParamsWorker.addParams(params, "Province", Province);
		ParamsWorker.addParams(params, "Name", Name);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 设置默认地址
	 * 
	 * @param AddressID
	 * @return
	 */
	public JSONObject setDefault(String AddressID) {
		// 拼接url
		String url = R.BASEURL + R.ADDRESS_SET_DEFAULT;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "AddressID", AddressID);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 编辑收货地址，邮编和是否默认不需要填写
	 * 
	 * @param IsDefault
	 * @param Area
	 * @param Phone
	 * @param Zipcode
	 * @param City
	 * @param AddressID
	 * @param Detail
	 * @param Province
	 * @param Name
	 * @return
	 */
	public JSONObject edit(String IsDefault, String Area, String Phone, String Zipcode, String City, String AddressID,
			String Detail, String Province, String Name) {
		// 拼接url
		String url = R.BASEURL + R.ADDRESS_EDIT;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "IsDefault", IsDefault);
		ParamsWorker.addParams(params, "Area", Area);
		ParamsWorker.addParams(params, "Phone", Phone);
		ParamsWorker.addParams(params, "Zipcode", Zipcode);
		ParamsWorker.addParams(params, "City", City);
		ParamsWorker.addParams(params, "AddressID", AddressID);
		ParamsWorker.addParams(params, "Detail", Detail);
		ParamsWorker.addParams(params, "Province", Province);
		ParamsWorker.addParams(params, "Name", Name);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}
}
