package com.haimi.hm.page;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;

import com.haimi.helper.HttpClientHelper;
import com.haimi.r.R;
import com.haimi.util.ParamsWorker;

import net.sf.json.JSONObject;

/**
 * invite Page
 * 
 * @author iris
 *
 */
public class Invite extends BasePage {

	public Invite(CookieStore cookie) {
		super(cookie);
	}

	/**
	 * 邀请码测试
	 * 
	 * @param memberid
	 * @return
	 */
	public JSONObject presentGet(String memberid) {
		// 拼接url
		String url = R.BASEURL + R.INVITE_PRESENT_GET;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "MemberID", memberid);

		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);

		return response;
	}

	public JSONObject index() {
		// 拼接url
		String url = R.BASEURL + R.INVITE_PRESENT_INDEX;
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, cookie);
		return response;
	}

	public JSONObject receive(String InviteCode) {
		// 拼接url
		String url = R.BASEURL + R.INVITE_PRESENT_RECEIVE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "InviteCode", InviteCode);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

}
