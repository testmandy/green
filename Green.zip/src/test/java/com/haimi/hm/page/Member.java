package com.haimi.hm.page;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;

import com.haimi.helper.CookiesHelper;
import com.haimi.helper.HttpClientHelper;
import com.haimi.helper.ResponseHelper;
import com.haimi.r.DBData;
import com.haimi.r.R;
import com.haimi.util.ParamsWorker;
import com.haimi.util.Signature;

import net.sf.json.JSONObject;

/**
 * 用户API
 * 
 * @author iris
 *
 */
public class Member extends BasePage {

	public Member(CookieStore cookie) {
		super(cookie);
	}

	/**
	 * 登录API
	 * 
	 * @param username
	 * @param password
	 * @param platform
	 * @param deviceid
	 * @param pushid
	 * @param belongto
	 * @return
	 */
	public JSONObject login(String username, String password, String platform, String deviceid, String pushid,
			String belongto) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_LOGIN;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "username", username);
		// 通过cookie判断，是否需要给密码加密
		if (CookiesHelper.isCookieVersionNew(cookie)) {
			password = Signature.encrypt(password);
		}
		ParamsWorker.addParams(params, "password", password);
		ParamsWorker.addParams(params, "platform", platform);
		ParamsWorker.addParams(params, "deviceID", deviceid);
		ParamsWorker.addParams(params, "pushID", pushid);
		ParamsWorker.addParams(params, "BelongTo", belongto);

		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);

		return response;
	}

	/**
	 * 退出登录
	 * 
	 * @return
	 */
	public JSONObject logout() {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_LOGOUT;

		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, cookie);

		return response;
	}

	/**
	 * 快捷登录 3.7.0新增接口
	 * 
	 * @param username
	 * @param code
	 * @return
	 */
	public JSONObject quickLogin(String username, String code) {
		String url = R.BASEURL + R.MEMBER_QUICK_LOGIN;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "username", username);
		ParamsWorker.addParams(params, "code", code);

		JSONObject res = HttpClientHelper.post(url, params, cookie);

		return res;
	}

	/**
	 * 发送快捷登录验证码 3.7.0新增
	 * 
	 * @param mobile
	 * @return
	 */
	public JSONObject sendQuickLoginCode(String mobile) {
		String url = R.BASEURL + R.MEMBER_SEND_QUICK_LOGIN_CODE;

		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "mobile", mobile);

		JSONObject response = HttpClientHelper.post(url, params, cookie);

		return response;
	}

	/**
	 * 获取快捷登录的验证码 3.7.0新增
	 * 
	 * @param mobile
	 * @return
	 */
	public String getQuickCode(String mobile) {
		// 确保验证码发送成功
		JSONObject response = sendQuickLoginCode(mobile);
		ResponseHelper.compareFlag(response, 1);
		// 返回验证码
		return DBData.getVerifyCode(mobile);
	}

	/**
	 * 发送手机验证码
	 * 
	 * @param mobile
	 * @return
	 */
	public JSONObject sendRegisterMobileCode(String mobile) {
		String url = R.BASEURL + R.MEMBER_SEND_REGISTER_MOBILE_CODE;

		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "mobile", mobile);

		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 1.发送验证码 2.获取手机验证码
	 * 
	 * @param mobile
	 * @return
	 */
	public String getVerifyCode(String mobile) {
		// 确保验证码发送成功
		JSONObject response = sendRegisterMobileCode(mobile);
		ResponseHelper.compareFlag(response, 1);
		// 返回验证码
		return DBData.getVerifyCode(mobile);
	}

	/**
	 * 手机号码注册，此功能未测试
	 * 
	 * @param mobile
	 * @param password
	 * @param code
	 * @param name
	 * @return
	 */
	public JSONObject registerByMobileCode(String mobile, String password, String code, String name) {
		String url = R.BASEURL + R.MEMBER_REGISTER_BY_MOBILE_CODE;

		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "mobile", mobile);
		// 通过cookie判断，是否需要给密码加密
		if (CookiesHelper.isCookieVersionNew(cookie)) {
			password = Signature.encrypt(password);
		}
		ParamsWorker.addParams(params, "password", password);
		ParamsWorker.addParams(params, "code", code);
		ParamsWorker.addParams(params, "name", name);

		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 设置用户邮箱
	 * 
	 * @param email
	 * @return
	 */
	public JSONObject setEmail(String email) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_SETEMAIL;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "Email", email);

		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);

		return response;
	}
	
	/**
	 * 获取环信密码
	 * @return
	 */
	public JSONObject getEasemobPassword() {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_GET_EASEMOB_PASSWORD;
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, cookie);
		return response;
	}
	
	/**
	 * 重置密码
	 * @param oldpassword
	 * @param newpassword
	 * @return
	 */
	public JSONObject resetPassword(String oldpassword, String newpassword) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_RESET_PASSWORD;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "old_password", oldpassword);
		ParamsWorker.addParams(params, "new_password", newpassword);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 仅当用户有绑定手机，且没有设置密码的情况下，可访问此接口设置密码
	 * @param password
	 * @param repassword
	 * @return
	 */
	public JSONObject setPassword(String password, String repassword) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_SET_PASSWORD;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "password", password);
		ParamsWorker.addParams(params, "repassword", repassword);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 支付密码找回-设置新支付密码
	 * @param password
	 * @param code
	 * @param repassword
	 * @param mobile
	 * @return
	 */
	public JSONObject setNewTrade(String password, String code, String repassword, String mobile) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_SET_NEW_TRADE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "password", password);
		ParamsWorker.addParams(params, "code", code);
		ParamsWorker.addParams(params, "repassword", repassword);
		ParamsWorker.addParams(params, "mobile", mobile);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 绑定新手机后合并账号，发送验证码到手机
	 * @param mobile
	 * @return
	 */
	public JSONObject sendMergeAccountCode(String mobile) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_SEND_MERGE_ACCOUNT_CODE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "mobile", mobile);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 设置交易密码
	 * @param oldpassword
	 * @param newpassword
	 * @return
	 */
	public JSONObject resetRefundPassword(String oldpassword, String newpassword) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_RESET_REFUND_PASSWORD;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "old_password", oldpassword);
		ParamsWorker.addParams(params, "new_password", newpassword);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

//	/**
//	 * 删除支付密码
//	 * @return
//	 */
//	public JSONObject deleteRefundPassword() {
//		String url = R.BASEURL + R.MEMBER_DELETE_REFUND_PASSWORD;
//		JSONObject response = HttpClientHelper.post(url, cookie);
//		return response;
//	}

	public JSONObject customCertificateList(String pageSize, String page) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_CUSTOM_CERTIFICATE_LIST;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "pageSize", pageSize);
		ParamsWorker.addParams(params, "page", page);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject sendResetPasswordMobile(String mobile) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_SEND_RESET_PASSWORD_MOBILE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "mobile", mobile);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject login(String password, String username) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_LOGIN;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "password", password);
		ParamsWorker.addParams(params, "username", username);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject setRefundPassword(String refundpassword) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_SET_REFUND_PASSWORD;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "refund_password", refundpassword);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject sendNewMobileCode(String mobile, String token) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_SEND_NEW_MOBILE_CODE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "mobile", mobile);
		ParamsWorker.addParams(params, "token", token);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject checkPassword(String password) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_CHECK_PASSWORD;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "password", password);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject checkNewMobileCode(String code, String mobile) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_CHECK_NEW_MOBILE_CODE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "code", code);
		ParamsWorker.addParams(params, "mobile", mobile);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject sendQuickLoginCode(String geetestseccode, String geetestvalidate, String mobile,
			String geetestchallenge) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_SEND_QUICK_LOGIN_CODE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "geetest_seccode", geetestseccode);
		ParamsWorker.addParams(params, "geetest_validate", geetestvalidate);
		ParamsWorker.addParams(params, "mobile", mobile);
		ParamsWorker.addParams(params, "geetest_challenge", geetestchallenge);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject addCustomCertificate(String IdcardImgFront, String IdcardImgBack, String IdcardCode,
			String Name) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_ADD_CUSTOM_CERTIFICATE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "IdcardImgFront", IdcardImgFront);
		ParamsWorker.addParams(params, "IdcardImgBack", IdcardImgBack);
		ParamsWorker.addParams(params, "IdcardCode", IdcardCode);
		ParamsWorker.addParams(params, "Name", Name);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject setSellerProfile(String SignatureUtils, String Sex, String avatar, String Birthday,
			String NickName) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_SET_SELLER_PROFILE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "SignatureUtils", SignatureUtils);
		ParamsWorker.addParams(params, "Sex", Sex);
		ParamsWorker.addParams(params, "_avatar", avatar);
		ParamsWorker.addParams(params, "Birthday", Birthday);
		ParamsWorker.addParams(params, "NickName", NickName);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject setNewPassword(String password, String code, String repassword, String mobile) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_SET_NEW_PASSWORD;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "password", password);
		ParamsWorker.addParams(params, "code", code);
		ParamsWorker.addParams(params, "repassword", repassword);
		ParamsWorker.addParams(params, "mobile", mobile);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	public JSONObject sendResetTradeMobile(String mobile) {
		// 拼接url
		String url = R.BASEURL + R.MEMBER_SEND_RESET_TRADE_MOBILE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "mobile", mobile);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}
}
