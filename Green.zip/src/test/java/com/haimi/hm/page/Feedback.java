package com.haimi.hm.page;

import java.util.ArrayList;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;
import com.haimi.helper.HttpClientHelper;
import com.haimi.r.R;
import com.haimi.util.ParamsWorker;
import net.sf.json.JSONObject;

/**
 * feedback
 * @author puff
 *
 */

public class Feedback extends BasePage {

	public Feedback(CookieStore cookie) {
		super(cookie);
	}

	public JSONObject post(String Content, String Mobile, String Name) {
		// 拼接url
		String url = R.BASEURL + R.FEEDBACK_POST;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "Content", Content);
		ParamsWorker.addParams(params, "Mobile", Mobile);
		ParamsWorker.addParams(params, "Name", Name);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}
}
