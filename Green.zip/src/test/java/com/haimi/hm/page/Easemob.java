package com.haimi.hm.page;

import org.apache.http.client.CookieStore;

import com.haimi.helper.HttpClientHelper;
import com.haimi.r.R;

import net.sf.json.JSONObject;

/**
 * 消息功能类
 * 
 * @author iris
 *
 */
public class Easemob extends BasePage {

	public Easemob(CookieStore cookie) {
		super(cookie);
	}

	/**
	 * 获取消息页面虚拟红包提醒（事实上与环信无关，只是放在消息列表里而已）
	 * 
	 * @return
	 */
	public JSONObject easemobGetVirtualBonusMessage() {
		String url = R.BASEURL + R.EASEMOB_GET_VIRTUAL_BONUS_MESSAGE;

		JSONObject response = HttpClientHelper.post(url, cookie);

		return response;
	}

}