package com.haimi.hm.page;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;

import com.haimi.helper.HttpClientHelper;
import com.haimi.r.R;
import com.haimi.util.ParamsWorker;

import net.sf.json.JSONObject;

/**
 * cart page
 * 
 * @author iris
 *
 */
public class Cart extends BasePage {

	public Cart(CookieStore cookie) {
		super(cookie);
	}

	/**
	 * 删除购物车中的单个商品
	 * 
	 * @param CartID
	 * @return
	 */
	public JSONObject delete(String CartID) {
		// 拼接url
		String url = R.BASEURL + R.CART_DELETE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "CartID", CartID);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 商品详情立即购买
	 * 
	 * @param Num
	 * @param ActivityID
	 * @param ProductID
	 * @param Specific
	 * @param SkuID
	 * @return
	 */
	public JSONObject checkoutSingle(String Num, String ActivityID, String ProductID, String Specific, String SkuID) {
		// 拼接url
		String url = R.BASEURL + R.CART_CHECKOUT_SINGLE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "Num", Num);
		ParamsWorker.addParams(params, "ActivityID", ActivityID);
		ParamsWorker.addParams(params, "ProductID", ProductID);
		ParamsWorker.addParams(params, "Specific", Specific);
		ParamsWorker.addParams(params, "SkuID", SkuID);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 购物车批量编辑
	 * 
	 * @param Updates
	 * @param Deletes
	 * @param Favorites
	 * @return
	 */
	public JSONObject batch(String Updates, String Deletes, String Favorites) {
		// 拼接url
		String url = R.BASEURL + R.CART_BATCH;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "Updates", Updates);
		ParamsWorker.addParams(params, "Deletes", Deletes);
		ParamsWorker.addParams(params, "Favorites", Favorites);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 购物车结算
	 * 
	 * @param CartIDs
	 * @param SellerIDs
	 * @return
	 */
	public JSONObject checkout(String CartIDs, String SellerIDs) {
		// 拼接url
		String url = R.BASEURL + R.CART_CHECKOUT;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "CartIDs", CartIDs);
		ParamsWorker.addParams(params, "SellerIDs", SellerIDs);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 购物车信息
	 * 
	 * @param SellerID
	 * @return
	 */
	public JSONObject info(String SellerID) {
		// 拼接url
		String url = R.BASEURL + R.CART_INFO;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "SellerID", SellerID);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 购物车计数
	 * 
	 * @param SellerID
	 * @return
	 */
	public JSONObject count(String SellerID) {
		// 拼接url
		String url = R.BASEURL + R.CART_COUNT;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "SellerID", SellerID);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 购物车活动信息
	 * 
	 * @param CartIDs
	 * @return
	 */
	public JSONObject promotionInfo(String CartIDs) {
		// 拼接url
		String url = R.BASEURL + R.CART_PROMOTION_INFO;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "CartIDs", CartIDs);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 加入购物车
	 * 
	 * @param Hm_Source
	 * @param Num
	 * @param ProductID
	 * @param Specific
	 * @param SkuID
	 * @return
	 */
	public JSONObject add(String HmSource, String Num, String ProductID, String Specific, String SkuID) {
		// 拼接url
		String url = R.BASEURL + R.CART_ADD;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "Hm_Source", HmSource);
		ParamsWorker.addParams(params, "Num", Num);
		ParamsWorker.addParams(params, "ProductID", ProductID);
		ParamsWorker.addParams(params, "Specific", Specific);
		ParamsWorker.addParams(params, "SkuID", SkuID);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 编辑购物车商品信息（数量等）
	 * 
	 * @param CartID
	 * @param Num
	 * @return
	 */
	public JSONObject edit(String CartID, String Num) {
		// 拼接url
		String url = R.BASEURL + R.CART_EDIT;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "CartID", CartID);
		ParamsWorker.addParams(params, "Num", Num);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 触发下单操作(从下单确认页)
	 * 
	 * @param SellerNotes
	 * @param SellerCoupons
	 * @param AddressID
	 * @param SellerFollows
	 * @param Coupon
	 * @param IdcardCode
	 * @return
	 */
	public JSONObject order(String SellerNotes, String SellerCoupons, String AddressID, String SellerFollows,
			String Coupon, String IdcardCode) {
		// 拼接url
		String url = R.BASEURL + R.CART_ORDER;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "SellerNotes", SellerNotes);
		ParamsWorker.addParams(params, "SellerCoupons", SellerCoupons);
		ParamsWorker.addParams(params, "AddressID", AddressID);
		ParamsWorker.addParams(params, "SellerFollows", SellerFollows);
		ParamsWorker.addParams(params, "Coupon", Coupon);
		ParamsWorker.addParams(params, "IdcardCode", IdcardCode);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 获取下单确认页需要显示的信息
	 * 
	 * @return
	 */
	public JSONObject getConfirm() {
		// 拼接url
		String url = R.BASEURL + R.CART_GET_CONFIRM;
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, cookie);
		return response;
	}

	/**
	 * 清除购物车失效宝贝
	 * 
	 * @param SellerNotes
	 * @param SellerCoupons
	 * @param AddressID
	 * @param SellerFollows
	 * @param Coupon
	 * @param IdcardCode
	 * @return
	 */
	public JSONObject clearInvalidProduct(String SellerID) {
		// 拼接url
		String url = R.BASEURL + R.CART_CLEAR_INVALID_PRODUCT;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "SellerID", SellerID);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}
}
