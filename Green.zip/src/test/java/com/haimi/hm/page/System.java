package com.haimi.hm.page;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;

import com.haimi.helper.HttpClientHelper;
import com.haimi.r.R;
import com.haimi.util.ParamsWorker;

import net.sf.json.JSONObject;

/**
 * 系统配置
 * 
 * @author iris
 *
 */
public class System extends BasePage {

	public System(CookieStore cookie) {
		super(cookie);
	}

	/**
	 * 获取系统配置 3.7.0修改接口
	 * 
	 * @param keys
	 * @param isLogin
	 * @return
	 */
	public JSONObject getConfig(String keys, String isLogin) {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_GET_CONFIG;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "keys", keys);
		ParamsWorker.addParams(params, "isLogin", isLogin);

		JSONObject response = HttpClientHelper.post(url, params, cookie);

		return response;
	}

	/**
	 * 通过美拍网页链接，解析出美拍视频链接 3.7.0新增接口
	 * 
	 * @param url
	 * @return
	 */
	public JSONObject getMeipaiVideoUrl(String Url) {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_GET_MEIPAI_VIDEO_URL;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "Url", Url);

		JSONObject response = HttpClientHelper.post(url, params, cookie);

		return response;
	}

	/**
	 * 记录用户设备是否开启通知 3.7.0新增接口
	 * 
	 * @param NotificationStatus
	 * @param deviceID
	 * @return
	 */
	public JSONObject logDeviceNotificationStatus(String NotificationStatus, String deviceID) {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_LOG_DEVICE_NOTIFICATION_STATUS;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "NotificationStatus", NotificationStatus);
		ParamsWorker.addParams(params, "deviceID", deviceID);

		JSONObject response = HttpClientHelper.post(url, params, cookie);

		return response;
	}

	/**
	 * 记录客户端传过来的未回复会话 3.7.0新增接口
	 * 
	 * @param toMemberID
	 * @return
	 */
	public JSONObject noAnswerChat(String toMemberIDs) {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_NO_ANSWER_CHAT;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "toMemberIDs", toMemberIDs);

		JSONObject response = HttpClientHelper.post(url, params, cookie);

		return response;
	}

	/**
	 * 获取服务器时间。
	 * 
	 * @return
	 */
	public JSONObject getTime() {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_GET_TIME;

		JSONObject response = HttpClientHelper.post(url, cookie);

		return response;
	}

	/**
	 * 获取网站相关信息 联系方式等
	 * 
	 * @return
	 */
	public JSONObject getSettingInfo() {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_GET_SETTING_INFO;

		JSONObject response = HttpClientHelper.get(url, cookie);

		return response;
	}

	/**
	 * isUploadCrashLog
	 * 
	 * @return
	 */
	public JSONObject isUploadCrashLog() {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_IS_UPLOAD_CRASH_LOG;
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, cookie);
		return response;
	}

	/**
	 * apiPorts
	 * 
	 * @return
	 */
	public JSONObject apiPorts() {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_API_PORTS;
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, cookie);
		return response;
	}

	/**
	 * appUpdate
	 * 
	 * @param platform
	 * @return
	 */
	public JSONObject appUpdate(String platform) {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_APP_UPDATE;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "platform", platform);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.get(url, params, cookie);
		return response;
	}

	/**
	 * ping
	 * 
	 * @return
	 */
	public JSONObject ping() {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_PING;
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, cookie);
		return response;
	}

	/**
	 * saveLoginTime
	 * 
	 * @return
	 */
	public JSONObject saveLoginTime() {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_SAVE_LOGIN_TIME;
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, cookie);
		return response;
	}

	/**
	 * 获取应用启动图。存在多个取第一个。
	 * 
	 * @param BelongTo
	 * @return
	 */
	public JSONObject startupImages(String BelongTo) {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_STARTUP_IMAGES;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "BelongTo", BelongTo);

		JSONObject response = HttpClientHelper.post(url, params, cookie);

		return response;
	}

	/**
	 * 获取APP客户端遗漏协议以及一些额外信息
	 * 
	 * @param platform
	 * @return
	 */
	public JSONObject getExtraAppInfo(String platform) {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_GET_EXTRA_APP_INFO;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "platform", platform);

		JSONObject response = HttpClientHelper.post(url, params, cookie);

		return response;
	}

	/**
	 * 获取品牌列表
	 * 
	 * @param Recommend
	 * @param key
	 * @return
	 */
	public JSONObject getBrands(String Recommend, String key) {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_GET_BRANDS;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "Recommend", Recommend);
		ParamsWorker.addParams(params, "key", key);
		JSONObject response = HttpClientHelper.post(url, params, cookie);

		return response;
	}

	/**
	 * 获取特定faq特定分类信息和相关标题
	 * 
	 * @param CategoryID
	 * @return
	 */
	public JSONObject faq(String CategoryID) {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_FAQ;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "CategoryID", CategoryID);
		JSONObject response = HttpClientHelper.get(url, params, cookie);

		return response;
	}

	/**
	 * 获取退款原因
	 * 
	 * @param IsTakeover
	 * @return
	 */
	public JSONObject getRefundReason(String IsTakeover) {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_GET_REFUND_REASON;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "IsTakeover", IsTakeover);
		JSONObject response = HttpClientHelper.post(url, params, cookie);

		return response;
	}

	/**
	 * 大数据推荐商品
	 * 
	 * @return
	 */
	public JSONObject getRecommendProducts() {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_GET_RECOMMEND_PRODUCTS;

		JSONObject response = HttpClientHelper.get(url, cookie);

		return response;
	}

	/**
	 * 分页获取底部推荐
	 * 
	 * @return
	 */
	public JSONObject getRecommend(String page, String pageSize) {
		// 拼接url
		String url = R.BASEURL + R.SYSTEM_GETRECOMMEND;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "page", page);
		ParamsWorker.addParams(params, "pageSize", pageSize);

		JSONObject response = HttpClientHelper.post(url, params, cookie);

		return response;
	}

}
