package com.haimi.hm.page;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;
import com.haimi.helper.HttpClientHelper;
import com.haimi.r.R;
import com.haimi.util.ParamsWorker;
import net.sf.json.JSONObject;

/**
 * search
 * 
 * @author iris
 *
 */
public class Search extends BasePage {

	public Search(CookieStore cookie) {
		super(cookie);
	}

	/**
	 * 搜索热词
	 * 
	 * @param type
	 * @return
	 */
	public JSONObject hotword(String type) {
		// 拼接url
		String url = R.BASEURL + R.SEARCH_HOTWORD;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "type", type);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.post(url, params, cookie);
		return response;
	}

	/**
	 * 搜索联想
	 * 
	 * @param Key
	 * @return
	 */
	public JSONObject suggest(String Key) {
		// 拼接url
		String url = R.BASEURL + R.SEARCH_SUGGEST;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "Key", Key);
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.get(url, params, cookie);
		return response;
	}

	/**
	 * 搜索产品
	 * 
	 * @param map
	 * @return
	 */
	public JSONObject product(HashMap<String, String> map) {
		// 拼接url
		String url = R.BASEURL + R.SEARCH_PRODUCT;
		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		for (String key : map.keySet()) {
			ParamsWorker.addParams(params, key, map.get(key));
		}
		// 执行请求，并获取请求返回
		JSONObject response = HttpClientHelper.get(url, params, cookie);
		return response;
	}
}
