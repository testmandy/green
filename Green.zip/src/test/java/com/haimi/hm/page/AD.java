package com.haimi.hm.page;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;

import com.haimi.helper.HttpClientHelper;
import com.haimi.r.R;
import com.haimi.util.ParamsWorker;

import net.sf.json.JSONObject;

/**
 * 广告功能
 * 
 * @author iris
 *
 */
public class AD extends BasePage {

	public AD(CookieStore cookie) {
		super(cookie);
	}

	/**
	 * 获取一个广告位的所有模块信息 4.0.0修改
	 * 
	 * @param Alias
	 * @param Date
	 * @param BelongTo
	 * @param Scene
	 * @return
	 */
	public JSONObject adModuleGet(String Alias, String AdModuleID, String Date, String BelongTo, String Scene) {

		String url = R.BASEURL + R.AD_MODULE_GET;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "Alias", Alias);
		ParamsWorker.addParams(params, "AdModuleID", AdModuleID);
		ParamsWorker.addParams(params, "Date", Date);
		ParamsWorker.addParams(params, "BelongTo", BelongTo);
		ParamsWorker.addParams(params, "Scene", Scene);

		JSONObject response = HttpClientHelper.post(url, params, cookie);

		return response;
	}

	/**
	 * 获取个性化广告位所包含的所有模块信息
	 * 
	 * @param Alias
	 * @param Date
	 * @param BelongTo
	 * @param Scene
	 * @return
	 */
	public JSONObject adModuleDynamic(String Alias, String Date, String BelongTo, String Scene) {

		String url = R.BASEURL + R.AD_MODULE_DYNAMIC;

		// 拼接传递的参数
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		ParamsWorker.addParams(params, "Alias", Alias);
		ParamsWorker.addParams(params, "Date", Date);
		ParamsWorker.addParams(params, "BelongTo", BelongTo);
		ParamsWorker.addParams(params, "Scene", Scene);

		JSONObject response = HttpClientHelper.post(url, params, cookie);

		return response;
	}

}
