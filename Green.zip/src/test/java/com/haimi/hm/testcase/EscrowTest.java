package com.haimi.hm.testcase;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.haimi.helper.JSONHelper;
import com.haimi.helper.ResponseHelper;
import com.haimi.hm.data.EscrowData;

import net.sf.json.JSONObject;

public class EscrowTest extends BaseTest {
	/*
	 * 
	 * 获取EscrowID
	 */
	public String getEscrowID(String Num, String ProductID, String AddressID, String Specific, String SkuID) {
		// 创建订单,获取EscrowID
		JSONObject Singleresponse = cart.checkoutSingle(Num, "NULL", ProductID, Specific, SkuID);
		ResponseHelper.compareFlag(Singleresponse, 1);
		// 创建订单
		JSONObject Escrowresponse = escrow.create("", "", "", "", Num, ProductID, "", SkuID, AddressID, "");

		ResponseHelper.compareFlag(Escrowresponse, 1);
		String escrowid = (String) JSONHelper.getSonJSONKeyValue(Escrowresponse, "data", "EscrowID");
		return escrowid;
	}

	/*
	 * 获取订单详情
	 */
	@Test(dataProvider = "detail")
	public void detail(String EscrowID, Object flag, String msg) {
		// 获取响应
		JSONObject response = escrow.detail(EscrowID);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1 && (String) msg == "ok") {
			System.out.println("1.1获取订单详情成功");
			String escrowid = (String) JSONHelper.getSonJSONKeyValue(response, "data", "EscrowID");
			String orderno = (String) JSONHelper.getSonJSONKeyValue(response, "data", "OrderNO");
			// JSONObject deleteresponse = escrow.delete(escrowid, orderno);
			// delete(escrowid,orderno,1,"删除成功");
			// 删除订单
			JSONObject responsedetail = escrow.delete(escrowid, orderno);
			ResponseHelper.compareFlag(responsedetail, 1);
			System.out.println("1.2删除_获取订单详情");

		} else {
			if ((int) flag == -1 && (String) msg == "订单不存在或已被删除") {
				System.out.println("1.3未传入订单ID");

			} else {
				if ((int) flag != 1 && (String) msg == "ok") {
					System.out.println("1.4返回值不是1");
				}

			}
		}

	}

	@DataProvider(name = "detail")
	public Object[][] detail() {
		return new Object[][] { { getEscrowID("1", "4141390", "171910", "", "0"), 1, "ok" },
				 { null, -1, "订单不存在或已被删除" },
				 { getEscrowID("1", "4141390", "171910", "", "0"), -1, "ok" }
		};
	}

	/*
	 * 创建订单
	 */
	@Test(dataProvider = "create", dataProviderClass = EscrowData.class)
	public void create(String BuyerNote, String Hm_Source, String Coupon, String Follow, String Num, String ProductID,
			String Specific, String SkuID, String AddressID, String IdcardCode, Object flag, String msg) {
		// 获取响应
		JSONObject Singleresponse = cart.checkoutSingle(Num, "NULL", ProductID, Specific, SkuID);
		ResponseHelper.compareFlag(Singleresponse, 1);

		JSONObject response = escrow.create(BuyerNote, Hm_Source, Coupon, Follow, Num, ProductID, Specific, SkuID,
				AddressID, IdcardCode);

		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			System.out.println("2.1创建订单成功");
			/*
			 * 删除创建的订单 获取响应结果
			 */

			String escrowid = (String) JSONHelper.getSonJSONKeyValue(response, "data", "EscrowID");
			String orderno = (String) JSONHelper.getSonJSONKeyValue(response, "data", "OrderNO");
			// delete(escrowid,orderno,1,"删除成功");
			// System.out.println("1.2删除创建的订单");
			// 删除订单
			JSONObject responsecreate = escrow.delete(escrowid, orderno);
			ResponseHelper.compareFlag(responsecreate, 1);
			System.out.println("2.2删除_创订单");



		} else
			System.out.println("2.3请输入收货地址");

	}

	/*
	 * 取消订单
	 */
	@Test(dataProvider = "cancel")
	public void cancel(String EscrowID, String Reason, Object flag, String msg) {
		// 获取响应
		JSONObject response = escrow.cancel(EscrowID, Reason);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			System.out.println("3.1取消订单成功");

			// 删除订单
			JSONObject responsecancel = escrow.delete(EscrowID, "");
			ResponseHelper.compareFlag(responsecancel, 1);
			System.out.println("3.2删除_取消订单");

		}
		else{
			System.out.println("3.3没有传订单ID");
		}
	}

	@DataProvider(name = "cancel")
	public Object[][] escrowid() {
		return new Object[][] { { getEscrowID("1", "4141390", "171910", "", "0"), "我不想买了", 1, "订单已取消" } ,
			{ "", "我不想买了", -1, "订单不存在或已被删除" }} ;//没有传订单ID
	}

	/*
	 * 删除订单
	 */
	@Test(dataProvider = "delete")
	public void delete(String EscrowID, String OrderNO, Object flag, String msg) {
		// 获取响应
		JSONObject response = escrow.delete(EscrowID, OrderNO);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);

		if ((int) flag == 1) {
			System.out.println("5.删除订单成功");
		}
		else{
			System.out.println("5.1没有传订单ID");
		}
	}

	@DataProvider(name = "delete")
	public Object[][] delete() {
		return new Object[][] { { getEscrowID("1", "4137037", "171910", "", "0"), "", 1, "删除成功" },
			{ "", "", -1, "订单不存在或已被删除" } };
	}

	/*
	 * 根据订单号，推荐商品
	 */
	@Test(dataProvider = "suggestProducts")
	public void suggestProducts(String EscrowIDs, Object flag, String msg) {
		// 获取响应
		JSONObject response = escrow.suggestProducts(EscrowIDs);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			System.out.println("4.1推荐商品成功");
			// 删除订单
			JSONObject responsesuggest = escrow.delete(EscrowIDs, "");
			ResponseHelper.compareFlag(responsesuggest, 1);
			System.out.println("4.2删除_推荐订单");
		}

	}

	@DataProvider(name = "suggestProducts")
	public Object[][] suggestProducts() {
		return new Object[][] { { getEscrowID("1", "4141390", "171910", "", "0"), 1, "" } };
	}

	/*
	 * 合并付款
	 */
	/*
	 * @Test(dataProvider = "payAllMerge") public void payAllMerge(String
	 * Coupon, String Credit, String RefundPassword, String Bonus, String Code,
	 * String Balance, String EscrowIDs, String Via,Object flag, String msg) {
	 * // 获取响应
	 * 
	 * JSONObject response = escrow.payAllMerge(Coupon, Credit, RefundPassword,
	 * Bonus, Code, Balance, EscrowIDs, Via); // 验证响应
	 * ResponseHelper.compareFlag(response, flag);
	 * ResponseHelper.compareMsg(response, msg); // if((String) msg=="付款成功"){
	 * if((int)flag == 1) { System.out.println("6.余額支付成功"); } }
	 * 
	 * @DataProvider(name = "payAllMerge") public Object[][] payAllMerge() {
	 * return new Object[][] { { "","0","123456","","","256.0",getEscrowID("1",
	 * "4039337", "171910", "", "0"), "alipay-app", "1","付款成功" } }; }
	 */

	@Test(dataProvider = "batchDetails")
	public void batchDetails(String EscrowIDs, Object flag, String msg) {
		// 获取响应
		JSONObject response = escrow.batchDetails(EscrowIDs);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			System.out.println("6.1批量获取订单详情");
			// 删除订单
			JSONObject responsebatch = escrow.delete(EscrowIDs, "");
			ResponseHelper.compareFlag(responsebatch, 1);
			System.out.println("6.2删除_批量获取订单");

		}
	}

	@DataProvider(name = "batchDetails")
	public Object[][] batchDetails() {
		return new Object[][] { { getEscrowID("1", "4141390", "171910", "", "0") + ","
				+ getEscrowID("1", "4080581", "171910", "颜色分类:蓝色", "1153") + ","
				+ getEscrowID("1", "4133776", "171910", "", "0"), 1, "" },
				// { null, -1, "订单不存在或已被删除" },
				// { getEscrowID("1", "4141390", "171910", "", "0"), -1, "ok" }
		};
	}

	/*
	 * 获取订单的清关信息
	 */
	// @Test(dataProvider = "customInfo", dataProviderClass = EscrowData.class)
	// public void customInfo(String EscrowID, Object flag, String msg) {
	// // 获取响应
	// JSONObject response = escrow.customInfo(EscrowID);
	// // 验证响应
	// ResponseHelper.compareFlag(response, flag);
	// ResponseHelper.compareMsg(response, msg);
	// }

	@Test(dataProvider = "buyerList", dataProviderClass = EscrowData.class)
	public void buyerList(String Status, String pageSize, String page, Object flag, String msg) {
		// 获取响应
		JSONObject response = escrow.buyerList(Status, pageSize, page);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1 && (String) msg == "ok") {
			System.out.println("7.1获取订单列表成功");
		}
	}

}