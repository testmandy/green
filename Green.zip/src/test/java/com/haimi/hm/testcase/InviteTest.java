package com.haimi.hm.testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.haimi.helper.JSONHelper;
import com.haimi.helper.ResponseHelper;
import com.haimi.hm.data.InviteData;
import net.sf.json.JSONObject;

/**
 * invite测试
 * 
 * @author iris
 *
 */
public class InviteTest extends BaseTest {

	/**
	 * 邀请码测试："/invite-present/get"
	 * 
	 * @param memberid
	 * @param flag
	 * @param nickname
	 */
	@Test(dataProvider = "presentGet", dataProviderClass = InviteData.class)
	public void presentGet(String memberid, int flag, String msg) {
		JSONObject response = invite.presentGet(memberid);
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if (flag == 1) {
			String code = (String) JSONHelper.getSonJSONKeyValue(response, "data", "InviteCode");
			Assert.assertTrue(code != null && !"".equals(code) && !"null".equals(code), "邀请码不存在");
		}
	}
	
	/**
	 * invite-present/index
	 * @param flag
	 * @param msg
	 */

	@Test(dataProvider = "index", dataProviderClass = InviteData.class)
	public void index(Object flag, String msg) {
		
		// 获取响应
		JSONObject response = invite.index();
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}
	
	/**
	 * invite-present/receive
	 * @param InviteCode
	 * @param flag
	 * @param msg
	 */

	@Test(dataProvider = "receive", dataProviderClass = InviteData.class)
	public void receive(String InviteCode, Object flag, String msg) {
		// 获取响应
		JSONObject response = invite.receive(InviteCode);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

}
