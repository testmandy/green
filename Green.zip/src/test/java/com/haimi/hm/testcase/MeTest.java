package com.haimi.hm.testcase;

import org.apache.http.client.CookieStore;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.haimi.helper.CookiesHelper;
import com.haimi.helper.JSONHelper;
import com.haimi.helper.ResponseHelper;
import com.haimi.hm.data.MeData;
import com.haimi.hm.page.Me;
import com.haimi.hm.page.Member;
import com.haimi.r.R;
import com.mysql.fabric.xmlrpc.base.Data;

import bsh.commands.dir;
import net.sf.json.JSONObject;

/**
 * Me
 * 
 * @author iris
 *
 */
public class MeTest {

	// cookie存储
	CookieStore cookieStore;

	Me me;
	Member member;

	/**
	 * 设置cookie信息，构造cookie 构造各个方法类的实例
	 * 
	 * @param version
	 * @param appname
	 * @param platform
	 */
	@Parameters({ "version", "appname", "platform" })
	@BeforeClass(alwaysRun = true)
	public void setup(@Optional("4.0.0") String version, @Optional("haimi") String appname,
			@Optional("IOS") String platform) {
		// 伪造cookie
		cookieStore = CookiesHelper.setCookie(R.BASEURL, version, appname, platform);

		// 构造实例
		me = new Me(cookieStore);
		member = new Member(cookieStore);
	}

	/**
	 * 测试路径："/me/profile" 测试账号的newcomer,DoLikes返回
	 * 测试账号的HasPaidEscrow,ReceiverMobile返回
	 * 
	 * @param username
	 * @param password
	 * @param Newcomer
	 * @param HasPaidEscrow
	 * @param ReceiverMobile
	 */
	@Test(dataProvider = "profile", dataProviderClass = MeData.class)
	public void profile(String username, String password, int flag, String msg) {
		String mymemberid = null;
		// 登录
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
			mymemberid = (String) JSONHelper.getSonJSONKeyValue(reslogin, "data", "MemberID");
		}

		// 获取用户信息，比较响应返回是否正确
		JSONObject response = me.profile();

		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);

		if (flag == 1) {
			ResponseHelper.compareJSON(response.getJSONObject("data"), "MemberID", mymemberid);
		}

		// 退出登录
		if (!username.isEmpty()) {
			JSONObject reslogout = member.logout();
			ResponseHelper.compareFlag(reslogout, 1);
		}
	}

	/**
	 * 测试路径："/me/own-info" 获取用户对此商品的优惠券信息，显示在商品详情页中，区分新老用户
	 * CheckMembersIsFollowed，CheckMallsIsLiked，BelongTo不需要测试，已经不用了
	 * 
	 * @param checkProductPromotion
	 * @param msg
	 * @param username
	 * @param password
	 */
	@Test(dataProvider = "ownInfo", dataProviderClass = MeData.class)
	public void ownInfo(String username, String password, String CheckProductsIsLiked, String checkProductPromotion,
			String deviceid, Object flag, String msg) {
		// 伪造cookie,判断是不是新设备
		String domain = R.BASEURL.split("/")[2];
		BasicClientCookie cookie = new BasicClientCookie("deviceID", deviceid);
		cookie.setDomain(domain);
		cookie.setPath("/");
		cookieStore.addCookie(cookie);
		// 登录
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
		}
		// 发送请求
		JSONObject response = me.ownInfo(CheckProductsIsLiked, checkProductPromotion, "null", "null", "null");
		// 对响应进行flag的比较
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		// 退出登录
		if (!username.isEmpty()) {
			JSONObject reslogout = member.logout();
			ResponseHelper.compareFlag(reslogout, 1);
		}
	}

	// /**
	// * 收藏测试："/me/favorites"
	// *
	// * @param type
	// * @param page
	// * @param pagesize
	// */
	// @Test(dataProvider = "favorites", dataProviderClass = MemData.class,
	// groups = { "login" })
	// public void favorites(String type, String page, String pagesize) {
	// JSONObject response = member.favorites(type, page, pagesize);
	// ResponseHelper.compareFlag(response, 1);
	// }

	@Test(dataProvider = "favorites", dataProviderClass = MeData.class)
	public void favorites(String username, String password, String pageSize, String page, String MarkDown,
			String Disabled, Object flag, String msg) {
		// 登录
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
		}
		// 获取响应
		JSONObject response = me.favorites(pageSize, page, MarkDown, Disabled);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		// 退出登录
		if (!username.isEmpty()) {
			JSONObject reslogout = member.logout();
			ResponseHelper.compareFlag(reslogout, 1);
		}
	}

	/**
	 * 测试路径："me/remove-view",删除我的足迹
	 * 
	 * @param ViewIDs
	 * @param RemoveAll
	 * @param flag
	 * @param msg
	 */

	@Test(dataProvider = "removeView", dataProviderClass = MeData.class)
	public void removeView(String username, String password, String ViewIDs, String RemoveAll, Object flag,
			String msg) {
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
		}
		// 获取响应
		JSONObject response = me.removeView(ViewIDs, RemoveAll);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if (!username.isEmpty()) {
			JSONObject reslogout = member.logout();
			ResponseHelper.compareFlag(reslogout, 1);
		}
	}

	/**
	 * 测试路径：me/buyer-status获取当前登录用登录信息
	 * 
	 * @param flag
	 * @param msg
	 */

	@Test(dataProvider = "buyerStatus", dataProviderClass = MeData.class)
	public void buyerStatus(String username, String password, Object flag, String msg) {
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
		}
		// 获取响应
		JSONObject response = me.buyerStatus("", "");
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if (!username.isEmpty()) {
			JSONObject reslogout = member.logout();
			ResponseHelper.compareFlag(reslogout, 1);
		}
	}

	/**
	 * 获取账户积分总值
	 * 
	 * @return
	 */
	public String getIntegral() {
		JSONObject responseIntegral = me.buyerStatus("", "");
		ResponseHelper.compareFlag(responseIntegral, 1);
		String integral = (String) JSONHelper.getSonJSONKeyValue(responseIntegral, "data", "Integral");
		return integral;
	}

	/**
	 * 测试路径：me/view-log 记录我的足迹
	 * 
	 * @param pageSize
	 * @param page
	 * @param flag
	 * @param msg
	 */

	@Test(dataProvider = "viewLog", dataProviderClass = MeData.class)
	public void viewLog(String username, String password, String pageSize, String page, Object flag, String msg) {
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
		}
		// 获取响应
		JSONObject response = me.viewLog(pageSize, page);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if (!username.isEmpty()) {
			JSONObject reslogout = member.logout();
			ResponseHelper.compareFlag(reslogout, 1);
		}
	}

	/**
	 * 测试路径：me/share-credit 分享送积分
	 * 
	 * @param flag
	 * @param msg
	 */

	@Test(dataProvider = "shareCredit", dataProviderClass = MeData.class)
	public void shareCredit(String username, String password, Object flag, String msg) {
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
		}
		// 获取响应
		JSONObject response = me.shareCredit("");
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if (!username.isEmpty()) {
			JSONObject reslogout = member.logout();
			ResponseHelper.compareFlag(reslogout, 1);
		}
	}

	/**
	 * 测试路径：me/get-credit-detail 获取积分详情
	 * 
	 * @param pageSize
	 * @param page
	 * @param flag
	 * @param msg
	 */

	@Test(dataProvider = "getCreditDetail", dataProviderClass = MeData.class)
	public void getCreditDetail(String username, String password, String pageSize, String page, Object flag,
			String msg) {
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
		}
		// 获取响应
		JSONObject response = me.getCreditDetail(pageSize, page);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if (!username.isEmpty()) {
			JSONObject reslogout = member.logout();
			ResponseHelper.compareFlag(reslogout, 1);
		}
	}

//	/**
//	 * me/get-login-info,获取当前登录用户的用户ID，用于海蜜，目前正在使用,接口不再是用
//	 * 
//	 * @param username
//	 * @param password
//	 * @param flag
//	 */
//	@Test(dataProvider = "getlogininfo", dataProviderClass = MeData.class)
//	public void getlogininfo(String username, String password, Object flag, String msg) {
//		if (!username.isEmpty()) {
//			JSONObject reslogin = member.login(username, password, "", "", "", "");
//			ResponseHelper.compareFlag(reslogin, 1);
//		}
//		JSONObject response = me.getlogininfo();
//		ResponseHelper.compareFlag(response, flag);
//		ResponseHelper.compareMsg(response, msg);
//		if (!username.isEmpty()) {
//			JSONObject reslogout = member.logout();
//			ResponseHelper.compareFlag(reslogout, 1);
//
//		}
//	}
}
