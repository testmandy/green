package com.haimi.hm.testcase;

import org.apache.http.impl.cookie.BasicClientCookie;
import org.testng.annotations.Test;

import com.haimi.helper.ResponseHelper;
import com.haimi.hm.data.EasemobData;
import com.haimi.r.R;

import net.sf.json.JSONObject;

/**
 * 消息测试类
 * 
 * @author iris
 *
 */
public class EasemobTest extends BaseTest {

	/**
	 * 测试路径：/easemob/get-virtual-bonus-message
	 * 获取消息页面虚拟红包提醒（事实上与环信无关，只是放在消息列表里而已）
	 * 
	 * @param deviceid
	 * @param newflag
	 */
	@Test(dataProvider = "easemobGetVirtualBonusMessage", dataProviderClass = EasemobData.class)
	public void easemobGetVirtualBonusMessage(String deviceid, int isNew, int flag, String msg) {
		// 需要先退出登录
		if (memberid != null) {
			member.logout();
			memberid = null;
		}
		// 伪造cookie,判断是不是新设备
		String domain = R.BASEURL.split("/")[2];
		BasicClientCookie cookie = new BasicClientCookie("deviceID", deviceid);
		cookie.setDomain(domain);
		cookie.setPath("/");

		cookieStore.addCookie(cookie);

		// 获取虚拟消息的响应
		JSONObject response = easemob.easemobGetVirtualBonusMessage();
		// 判断响应的正确性
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		// 判断是不是新设备
		if (isNew == 1) {
			ResponseHelper.compareSonJSON(response, "data", "NickName", "新人优惠");
		} else {
			ResponseHelper.compareJSON(response, "data", "{}");
		}
	}
}
