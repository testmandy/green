package com.haimi.hm.testcase;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.haimi.helper.JSONHelper;
import com.haimi.helper.ResponseHelper;
import com.haimi.hm.data.EscrowData;

import net.sf.json.JSONObject;

public class EscrowTest2 extends BaseTest {
	/*
	 * 
	 * 获取EscrowID
	 */
	public String getEscrowID(String Num, String ProductID, String AddressID, String Specific, String SkuID) {
		// 创建订单,获取EscrowID
		JSONObject Singleresponse = cart.checkoutSingle(Num, "NULL", ProductID, Specific, SkuID);
		ResponseHelper.compareFlag(Singleresponse, 1);
		// 创建订单
		JSONObject Escrowresponse = escrow.create("", "", "", "", Num, ProductID, "", SkuID, AddressID, "");

		ResponseHelper.compareFlag(Escrowresponse, 1);
		String escrowid = (String) JSONHelper.getSonJSONKeyValue(Escrowresponse, "data", "EscrowID");
		return escrowid;
	}

	
	//提醒卖家发货。
		@Test(dataProvider = "remindShip")
		public void remindShip(String EscrowID, Object flag, String msg) {
			// 获取响应
			JSONObject response = escrow.remindShip(EscrowID);
			// 验证响应
			ResponseHelper.compareFlag(response, flag);
			ResponseHelper.compareMsg(response, msg);
			if((int)flag ==1 ){
				System.out.println("9.1您已提醒买手发货。");
				// 删除订单
				JSONObject responsegetArgueAmountDetail = escrow.delete(EscrowID, "");
				ResponseHelper.compareFlag(responsegetArgueAmountDetail, 1);
				System.out.println("9.3删除_订单");
			}
			else{
				System.out.println("9.2未传订单ID");
			}
			
		}
		
		@DataProvider(name = "remindShip")
		public Object[][] remindShip() {
			return new Object[][] { {getEscrowID("1", "4137037", "171910", "", "0"), 1, "您已提醒买手发货。" },
//				{"", 1, "" } //未传订单ID
			};
		}
		

/*		
		 * 
		 * 获取 争议订单ArgueID
		 */
		public String getArgueID(String BuyerNote, String BuyerReason, String ArgueType, String Amount, String EscrowID,
				String IsTakeover, Object flag, String msg) {
			// 获取响应
			JSONObject responseGetArgueID = escrow.applyArgue(BuyerNote, BuyerReason, ArgueType, Amount, EscrowID, IsTakeover);
			ResponseHelper.compareFlag(responseGetArgueID, 1);
			String argueID = (String) JSONHelper.getSonJSONKeyValue(responseGetArgueID, "data", "ArgueID");
			return argueID;

		}		
		
		
		
		
	
	//买家申请退款、修改退款申请。
		@Test(dataProvider = "applyArgue")
		public void applyArgue(String BuyerNote, String BuyerReason, String ArgueType, String Amount, String EscrowID,
				String IsTakeover, Object flag, String msg) {
			
			// 获取响应
			JSONObject response = escrow.applyArgue(BuyerNote, BuyerReason, ArgueType, Amount, EscrowID, IsTakeover);
			// 验证响应
			ResponseHelper.compareFlag(response, flag);
			ResponseHelper.compareMsg(response, msg);
			if((int)flag==1){
				System.out.println("11.1退款申请提交成功。");
			}
			else{
				System.out.println("11.2订单当前状态不支持申请退款");}
			}
	
		@DataProvider(name = "applyArgue")
		public Object[][] applyArgue() {
			return new Object[][] { {"申请退款","卖家缺货","ONLY_MONEY","69.00",getEscrowID("1", "4137037", "171910", "", "0"), "N","-1", "退款申请提交成功。" },//未收到货
				{"申请退款","卖家缺货","PRODUCT_MONEY","60",getEscrowID("1", "4137037", "171910", "", "0"), "Y","-1", "退款申请提交成功。" }//已收到货
			};
		
		}
		
		
	//获取可退款明细
	@Test(dataProvider = "getArgueAmountDetail", dataProviderClass = EscrowData.class)
	public void getArgueAmountDetail(String Amount, String EscrowID, String SkuID, Object flag, String msg) {
		// 获取响应
		JSONObject response = escrow.getArgueAmountDetail(Amount, EscrowID, SkuID);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if((int) flag==1)
			System.out.println("8.1获取可退款明细");
		// 删除订单
		JSONObject responsegetArgueAmountDetail = escrow.delete(EscrowID, "");
		ResponseHelper.compareFlag(responsegetArgueAmountDetail, 1);
		System.out.println("8.2删除_获取可退款明细");
		
	}
	
	@DataProvider(name = "getArgueAmountDetail")
	public Object[][] getArgueAmountDetail() {
		return new Object[][] { {"89.00", getEscrowID("1", "4137037", "171910", "", "0"), "0", 1, "" },
			{"90.00", getEscrowID("1", "4137037", "171910", "", "0"), "0", 1, "" } };
	}
	
	
//获取订单争议详情。
	@Test(dataProvider = "argueDetail", dataProviderClass = EscrowData.class)
	public void argueDetail(String ArgueID, Object flag, String msg,String EscrowID ) {
		
		
		// 获取响应
		
		JSONObject response = escrow.argueDetail(ArgueID);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if((int)flag==1){
			System.out.println("10.1获取争议订单详情");
			// 删除订单
			JSONObject responseargueDetail = escrow.delete(EscrowID, "");
			ResponseHelper.compareFlag(responseargueDetail, 1);
			System.out.println("10.2删除_获取可退款明细");
			
		}
		
	}


	@DataProvider(name = "argueDetail")
	public Object[][] argueDetail() {
		return new Object[][] { {getArgueID("申请退款","卖家缺货","FULL_RETURN","50",getEscrowID("1", "4137037", "171910", "", "0"), "N",1, "退款申请提交成功。" ),1,"ok"//已收到货
		}};
	
	}
	
	
	
//买家撤销退款申请。
	@Test(dataProvider = "cancelArgue", dataProviderClass = EscrowData.class)
	public void cancelArgue(String EscrowID, String SkuID, Object flag, String msg,String BuyerNote,String BuyerReason,String ArgueType,String Amount, String IsTakeover) {
		// 获取响应
		JSONObject responseArgue = escrow.applyArgue(BuyerNote, BuyerReason, ArgueType, Amount, EscrowID, IsTakeover);
		// 验证响应
		ResponseHelper.compareFlag(responseArgue, 1);
		// 获取响应
		JSONObject response = escrow.cancelArgue(EscrowID, SkuID);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if((int)flag==1){
			System.out.println("11.1买家撤销退款申请");
			// 删除订单
			JSONObject responsecancelArgue = escrow.delete(EscrowID, "");
			ResponseHelper.compareFlag(responsecancelArgue, 1);
			System.out.println("11.2删除_获取可退款明细");
		}
	}

	@DataProvider(name = "cancelArgue")
	public Object[][] cancelArgue() {
		return new Object[][] { {"申请退款","卖家缺货","FULL_RETURN","50",getEscrowID("1", "4137037", "171910", "", "0"), "N",1, "退款申请提交成功。" },//未收到货
//			{"申请退款","卖家缺货","FULL_RETURN","60",getEscrowID("1", "4137037", "171910", "", "0"), "Y",1, "退款申请提交成功。" }//已收到货
		};
	}

}