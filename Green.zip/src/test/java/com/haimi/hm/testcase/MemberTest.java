package com.haimi.hm.testcase;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.haimi.helper.ResponseHelper;
import com.haimi.hm.data.MemberData;
import com.haimi.r.DBData;
import net.sf.json.JSONObject;

/**
 * 用户测试
 * 
 * @author iris
 *
 */
public class MemberTest extends BaseTest {
	/**
	 * 设置邮箱测试："/member/setemail"
	 * 
	 * @param email
	 * @param flag
	 */
	@Test(dataProvider = "setEmail", dataProviderClass = MemberData.class)
	public void setEmail(String email, Object flag, String msg) {
		JSONObject response = member.setEmail(email);
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ("操作成功".equals(msg)) {
			String dbEmail = DBData.getEmail(memberid);
			Assert.assertEquals(dbEmail, email);
		}
	}

	/**
	 * member/get-easemob-password,获取环信密码
	 * 
	 * @param username
	 * @param password
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "getEasemobPassword", dataProviderClass = MemberData.class)
	public void getEasemobPassword(String username, String password, Object flag, String msg) {
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
		}
		// 获取响应
		JSONObject response = member.getEasemobPassword();
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if (!username.isEmpty()) {
			JSONObject reslogout = member.logout();
			ResponseHelper.compareFlag(reslogout, 1);
		}
	}

	/**
	 * member/reset-password,重置密码
	 * 
	 * @param oldpassword
	 * @param newpassword
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "resetPassword", dataProviderClass = MemberData.class)
	public void resetPassword(String username, String password, String oldpassword, String newpassword, int flag,
			String msg) {
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
		}
		// 获取响应
		JSONObject response = member.resetPassword(oldpassword, newpassword);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if (flag == 1) {
			JSONObject reslogout1 = member.logout();
			ResponseHelper.compareFlag(reslogout1, 1);
			JSONObject reslogin = member.login(username, newpassword, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
			JSONObject response1 = member.resetPassword(newpassword, password);
			ResponseHelper.compareFlag(response1, flag);
		}
		if (!username.isEmpty()) {
			JSONObject reslogout = member.logout();
			ResponseHelper.compareFlag(reslogout, 1);
		}

	}

//	/**
//	 * member/set-password,仅当用户有绑定手机，且没有设置密码的情况下，可访问此接口设置密码，接口需要创造新账户暂时不测
//	 * 
//	 * @param password
//	 * @param repassword
//	 * @param flag
//	 * @param msg
//	 */
//	@Test(dataProvider = "setPassword", dataProviderClass = MemberData.class)
//	public void setPassword(String username, String password, String repassword, int flag, String msg) {
//		JSONObject reslogout1 = member.logout();
//		ResponseHelper.compareFlag(reslogout1, 1);
//		if (!username.isEmpty()) {
//			JSONObject reslogin = member.quickLogin(username, member.getQuickCode(username));
//			ResponseHelper.compareFlag(reslogin, 1);
//		}
//		// 获取响应
//		JSONObject response = member.setPassword(password, repassword);
//		// 验证响应
//		ResponseHelper.compareFlag(response, flag);
//		ResponseHelper.compareMsg(response, msg);
//		if (!username.isEmpty()) {
//			JSONObject reslogout = member.logout();
//			ResponseHelper.compareFlag(reslogout, 1);
//		}
//	}

	/**
	 * member/set-new-trade，支付密码找回-设置新支付密码
	 * 
	 * @param password
	 * @param code
	 * @param repassword
	 * @param mobile
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "setNewTrade")
	public void setNewTrade(String password, String code, String repassword, String mobile, Object flag, String msg) {
		// 获取响应
		JSONObject response = member.setNewTrade(password, code, repassword, mobile);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	@DataProvider(name = "setNewTrade")
	public static Object[][] setNewTrade() {
		return new Object[][] {
				{ "123456", member.getQuickCode("18056020694"), "123456", "18056020694", 1, "支付密码更新成功" },
				{ "121212", member.getQuickCode("18056020694"), "1212", "18056020694", -1, "两次密码输入不一致" },
				{ "121212", member.getQuickCode("18056020694"), "", "18056020694", -1, "两次密码输入不一致" },
				{ "null", member.getQuickCode("18056020694"), "null", "18056020694", -1, "支付密码必须为6位数字" },
				{ null, member.getQuickCode("18056020694"), null, "18056020694", -1, "支付密码必须为6位数字" },
				{ "121212", member.getQuickCode("18056020694"), "null", "18056020694", -1, "两次密码输入不一致" },
				{ "121212", "", "121212", "18056020694", -1, "验证码格式错误" },
				{ "121212", "null", "121212", "18056020694", -1, "验证码格式错误" },
				{ "121212", "000000", "121212", "18056020694", -1, "验证码错误" } };
	}

	/**
	 * member/send-merge-account-code,绑定新手机后合并账号，发送验证码到手机
	 * 
	 * @param mobile
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "sendMergeAccountCode", dataProviderClass = MemberData.class)
	public void sendMergeAccountCode(String mobile, Object flag, String msg) {
		// 获取响应
		JSONObject response = member.sendMergeAccountCode(mobile);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	// /**
	// * member/set-refund-password,设置交易密码，需要创造新的账号，暂时不测
	// *
	// * @param refundpassword
	// * @param flag
	// * @param msg
	// */
	// @Test(dataProvider = "setRefundPassword", dataProviderClass =
	// MemberData.class)
	// public void setRefundPassword(String username, String password, String
	// refundpassword, Object flag, String msg) {
	// if (!username.isEmpty()) {
	// JSONObject reslogin = member.login(username, password, "", "", "", "");
	// ResponseHelper.compareFlag(reslogin, 1);
	// }
	// // 获取响应
	// JSONObject response1 = member.setRefundPassword(refundpassword);
	// // 验证响应
	// ResponseHelper.compareFlag(response1, flag);
	// ResponseHelper.compareMsg(response1, msg);
	// }

	/**
	 * member/reset-refund-password,通过旧的交易密码设置新的交易密码
	 * 
	 * @param oldpassword
	 * @param newpassword
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "resetRefundPassword", dataProviderClass = MemberData.class)
	public void resetRefundPassword(String username, String password, String oldpassword, String newpassword, int flag,
			String msg) {
		JSONObject reslogout1 = member.logout();
		ResponseHelper.compareFlag(reslogout1, 1);
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
		}
		// 获取响应
		JSONObject response = member.resetRefundPassword(oldpassword, newpassword);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	 	if (flag == 1) {
			JSONObject response1 = member.resetRefundPassword(newpassword, oldpassword);
			ResponseHelper.compareFlag(response1, 1);
		}
		// if (!username.isEmpty()) {
		// JSONObject reslogout = member.logout();
		// ResponseHelper.compareFlag(reslogout, 1);
		// }
	}

	/**
	 * member/logout,退出
	 * 
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "logout", dataProviderClass = MemberData.class)
	public void logout(String username, String password, Object flag, String msg) {
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
		}
		// 获取响应
		JSONObject response = member.logout();
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

}
