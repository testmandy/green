package com.haimi.hm.testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.haimi.helper.JSONHelper;
import com.haimi.helper.ResponseHelper;
import com.haimi.hm.data.UserData;

import net.sf.json.JSONObject;

/**
 * 用户签到
 * 
 * @author iris
 *
 */
public class UserTest extends BaseTest {

	/**
	 * 每日签到列表
	 * 
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "signInfo", dataProviderClass = UserData.class)
	public void signInfo(int flag, String msg) {
		// 客户端传id
		JSONObject response = user.signInfo();
		// 判断返回是否正确
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	/**
	 * 签到
	 * 
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "signSign", dataProviderClass = UserData.class)
	public void signSign(int flag, String msg) {
		// 客户端传id
		JSONObject response = user.signSign();
		// 判断返回是否正确
		ResponseHelper.compareFlag(response, flag);
		if (flag == 1) {
			JSONObject inforesponse = user.signInfo();
			if (!(boolean) JSONHelper.getSonJSONKeyValue(inforesponse, "data", "TodaySigned")) {
				Assert.assertTrue(response.toString().contains(msg), "今天未签到时，应该返回签到成功");
			}
		}
	}
}
