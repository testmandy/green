package com.haimi.hm.testcase;

import org.apache.http.client.CookieStore;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.haimi.helper.CookiesHelper;
import com.haimi.helper.JSONHelper;
import com.haimi.helper.ResponseHelper;
import com.haimi.hm.data.MemberData;
import com.haimi.hm.page.Member;
import com.haimi.r.DBData;
import com.haimi.r.R;

import net.sf.json.JSONObject;

/**
 * 登录测试
 * 
 * @author iris
 *
 */
public class LoginTest {

	// cookie存储
	CookieStore cookieStore;

	Member member;

	/**
	 * 设置cookie信息，构造cookie 构造各个方法类的实例
	 * 
	 * @param version
	 * @param appname
	 * @param platform
	 */
	@Parameters({ "version", "appname", "platform" })
	@BeforeClass(alwaysRun = true)
	public void setup(@Optional("4.0.0") String version, @Optional("haimi") String appname,
			@Optional("IOS") String platform) {
		// 伪造cookie
		cookieStore = CookiesHelper.setCookie(R.BASEURL, version, appname, platform);

		// 构造实例
		member = new Member(cookieStore);
	}

	/**
	 * 登录测试路径："/member/login"
	 * 
	 * @param username
	 * @param password
	 * @param platform
	 * @param deviceid
	 * @param pushid
	 * @param belongto
	 */
	@Test(dataProvider = "login", dataProviderClass = MemberData.class)
	public void login(String username, String password, String platform, String deviceid, String pushid,
			String belongto, int flag, String msg) {
		// 登录，获取响应
		JSONObject response = member.login(username, password, platform, deviceid, pushid, belongto);

		// 验证结果，退出登录
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if (flag == 1) {
			// 验证响应信息
			String id = (String) JSONHelper.getSonJSONKeyValue(response, "data", "MemberID");
			Assert.assertTrue(id != null && !"".equals(id) && !"null".equals(id), "登录后memberid不存在");
			// 最终需要退出登录
			member.logout();
		}
	}

	/**
	 * 快捷登录api测试："/member/quick-login"
	 * 
	 * @param mobile
	 * @param code
	 * @param flag
	 */
	@Test(dataProvider = "quickLogin")
	public void quickLogin(String mobile, String code, int flag, String msg) {
		// 登录
		JSONObject response = member.quickLogin(mobile, code);

		// 验证登录结果
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		// 退出登录
		if (flag == 1) {
			// 验证响应信息
			String id = (String) JSONHelper.getSonJSONKeyValue(response, "data", "MemberID");
			Assert.assertTrue(id != null && !"".equals(id) && !"null".equals(id), "登录后memberid不存在");
			// 最终需要退出登录
			member.logout();
		}
	}

	/*
	 * 快捷登录 mobile，code，flag
	 */
	@DataProvider(name = "quickLogin")
	public Object[][] quickLogin() {
		return new Object[][] { { "18012345678", "1111", -1, "验证码错误" }, // 错误的验证码
				{ "18012345678", "", -1, "请输入验证码。" }, // 错误的验证码
				{ "18012345678", "null", -1, "请输入验证码。" }, // 错误的验证码
				{ "18012345678", null, -1, "请输入验证码。" }, // 错误的验证码
				{ "null", "1111", -1, "请输入有效的手机号码。" }, // 手机号码为null
				{ "", "11111", -1, "请输入有效的手机号码。" }, // 手机号码为空
				{ null, "1111", -1, "请输入有效的手机号码。" }, // 手机号码为null
				{ "15012345678", member.getQuickCode("15012345678"), 1, "登录成功" }, // 正确的组合
				{ "12345678901", member.getQuickCode("12345678901"), 1, "登录成功" }, // 手机号码数字验证，其他不验证，所以用例正确
				{ "1231546545464213123", member.getQuickCode("1231546545464213123"), 1, "登录成功" }// 手机号码格式不正确
		};
	}

	/**
	 * 发送快捷登录验证码测试："/member/send-quick-login-code"
	 * 
	 * @param mobile
	 * @param flag
	 */
	@Test(dataProvider = "sendQuickLoginCode", dataProviderClass = MemberData.class)
	public void sendQuickLoginCode(String mobile, int flag, String msg) {
		// 发送请求
		JSONObject response = member.sendQuickLoginCode(mobile);
		// 比较返回响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		// 数据库,判断验证码类型
		if (flag == 1)
			DBData.compareCodeType(mobile, 10);
	}

	/**
	 * 发送手机注册的验证码:"/member/send-register-mobile-code"
	 * 
	 * @param mobile
	 * @param flag
	 */
	@Test(dataProvider = "sendRegisterMobileCode", dataProviderClass = MemberData.class)
	public void sendRegisterMobileCode(String mobile, int flag, String msg) {
		// 发送请求
		JSONObject response = member.sendRegisterMobileCode(mobile);
		// 比较返回响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		// 数据库,判断验证码类型
		if (flag == 1)
			DBData.compareCodeType(mobile, 5);
	}

}
