package com.haimi.hm.testcase;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.haimi.helper.ResponseHelper;
import net.sf.json.JSONObject;
import com.haimi.hm.data.NavData;

/**
 * nav
 * 
 * @author iris
 *
 */
public class NavTest extends BaseTest {

	/**
	 * /nav/list
	 * 
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "list", dataProviderClass = NavData.class)
	public void list(Object flag, String msg) {
		// 获取响应
		JSONObject response = nav.list();
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			Assert.assertTrue(response.toString().contains("推荐"), "首页导航未含有推荐栏目");
		}
	}

	/**
	 * /nav/advert-team-products
	 * 
	 * @param NavID
	 * @param NavAlias
	 * @param pageSize
	 * @param page
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "advertTeamProducts", dataProviderClass = NavData.class)
	public void advertTeamProducts(String NavID, String pageSize, String page, Object flag, String msg) {
		// 获取响应
		JSONObject response = nav.advertTeamProducts(NavID, pageSize, page);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}
}
