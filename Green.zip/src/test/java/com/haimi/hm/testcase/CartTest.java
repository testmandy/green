package com.haimi.hm.testcase;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.haimi.helper.JSONHelper;
import com.haimi.helper.ResponseHelper;
import com.haimi.hm.data.CartData;

import net.sf.json.JSONObject;

/**
 * cart test
 * 
 * @author iris
 *
 */
public class CartTest extends BaseTest {

	/**
	 * 通过加入购物车获取cartid
	 * 
	 * @param Num
	 * @param ProductID
	 * @param SkuID
	 * @return
	 */
	public String getCartID(String Num, String ProductID, String SkuID) {
		// 添加购物车,获取CartID
		JSONObject responseAdd = cart.add("null", Num, ProductID, "null", SkuID);
		ResponseHelper.compareFlag(responseAdd, 1);
		String cartid = (String) JSONHelper.getSonJSONKeyValue(responseAdd, "data", "CartID");
		return cartid;
	}

	/**
	 * /cart/add
	 * 
	 * @param Hm_Source
	 * @param Num
	 * @param ProductID
	 * @param Specific
	 * @param SkuID
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "add", dataProviderClass = CartData.class)
	public void add(String HmSource, String Num, String ProductID, String Specific, String SkuID, Object flag,
			String msg) {
		// 获取响应
		JSONObject response = cart.add(HmSource, Num, ProductID, Specific, SkuID);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			String cartid = (String) JSONHelper.getSonJSONKeyValue(response, "data", "CartID");
			Assert.assertTrue(cartid != null, "添加购物车后的cartid为空");
			// 根据info获取购物车的cartid，验证是否包含当前增加的商品的cartid
			JSONObject inforesponse = cart.info(null);
			// 验证响应
			ResponseHelper.compareFlag(inforesponse, 1);
			Assert.assertTrue(inforesponse.toString().contains(cartid), "当前购物车中没有新增的商品");
			// 删除增加的商品
			JSONObject deleteresponse = cart.delete(cartid);
			// 验证响应
			ResponseHelper.compareFlag(deleteresponse, 1);
		}
	}

	/**
	 * /cart/delete
	 * 
	 * @param Num
	 * @param ProductID
	 * @param SkuID
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "delete")
	public void delete(String CartID, Object flag, String msg) {
		// 通过购物车total判断delete操作正确
		JSONObject responseInfo1 = cart.info(null);
		ResponseHelper.compareFlag(responseInfo1, 1);
		String total1 = (String) JSONHelper.getSonJSONKeyValue(responseInfo1, "extra", "total");
		// 获取响应
		JSONObject response = cart.delete(CartID);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			// 通过购物车total判断delete操作正确
			JSONObject responseInfo2 = cart.info(null);
			ResponseHelper.compareFlag(responseInfo2, 1);
			String total2 = (String) JSONHelper.getSonJSONKeyValue(responseInfo2, "extra", "total");
			Assert.assertTrue(!total1.equals(total2), "delete操作后total依然相同");
			// 删除cartid
			JSONObject responsebatch = cart.batch("null", CartID, "null");
			ResponseHelper.compareFlag(responsebatch, 1);
		}
	}

	@DataProvider(name = "delete")
	public Object[][] delete() {
		return new Object[][] { { "null", -1, "此记录不存在。" }, { "", -1, "此记录不存在。" }, { null, -1, "此记录不存在。" },
				{ "wrong", -1, "此记录不存在。" }, { "111,11111", -1, "" }, // 不存在的cartid记录应该报错的，现在是对的
				{ "11111111", -1, "" }, // 不存在的cartid记录应该报错的，现在是对的
				{ getCartID("1", "4039458", ""), 1, "" }, { getCartID("1", "4080581", "1152"), 1, "" } };
	}

	/**
	 * /cart/info
	 * 
	 * @param SellerID
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "info", dataProviderClass = CartData.class)
	public void info(String SellerID, Object flag, String msg) {
		// 获取响应
		JSONObject response = cart.info(SellerID);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	/**
	 * /cart/count
	 * 
	 * 此接口与cart/info中total的功能是一样的
	 * 
	 * @param SellerID
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "count", dataProviderClass = CartData.class)
	public void count(String SellerID, Object flag, String msg) {
		// 获取响应
		JSONObject response = cart.count(SellerID);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	/**
	 * /cart/promotion-info
	 * 
	 * @param CartIDs
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "promotionInfo")
	public void promotionInfo(String CartIDs, Object flag, String msg) {
		// 获取响应
		JSONObject response = cart.promotionInfo(CartIDs);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			// 删除cartid
			JSONObject responsebatch = cart.batch("null", CartIDs, "null");
			ResponseHelper.compareFlag(responsebatch, 1);
		}
	}

	@DataProvider(name = "promotionInfo")
	public Object[][] promotionInfo() {
		String cartid1 = getCartID("1", "4039458", "");
		String cartid2 = getCartID("1", "4080581", "1152");

		return new Object[][] { { "", -1, "请选择至少一个商品" }, { "null", -1, "请选择至少一个商品" }, { null, -1, "请选择至少一个商品" },
				{ "wrong", -1, "数据格式异常" }, // 错误格式的id不应该返回OK,批量删除时会报错
				{ "111,11111", 1, "ok" }, { "111111111", 1, "ok" }, { cartid2, 1, "ok" },
				{ cartid1 + "," + cartid2, 1, "ok" }, { cartid1 + "，" + cartid2, -1, "数据格式异常" } // 分隔符使用的错误的符号，不应该返回ok,批量删除时会报错
		};
	}

	/**
	 * /cart/batch
	 * 
	 * @param Updates
	 * @param Deletes
	 * @param Favorites
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "batch")
	public void batch(String Updates, String Deletes, String Favorites, Object flag, String msg) {
		// 获取响应
		JSONObject response = cart.batch(Updates, Deletes, Favorites);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	@DataProvider(name = "batch")
	public Object[][] batch() {
		String cartid1 = getCartID("1", "4080581", "1152");
		String cartid2 = getCartID("1", "4039458", "");
		String cartid3 = getCartID("1", "4141726", "2836");
		String cartid4 = getCartID("1", "4141726", "2837");
		String cartid5 = getCartID("1", "4309530", "3314");
		String cartid6 = getCartID("1", "4142610", "");
		return new Object[][] { { "", "", "", 1, "修改成功" }, { "null", "null", "null", 1, "修改成功" },
				{ null, null, null, 1, "修改成功" }, { "11111:2", "", "", -1, "购物车商品不存在或已删除" },
				{ "", "111111", "", 1, "修改成功" }, { "", "", "1111111", -1, "购物车商品不存在或已删除" }, // 当cartid不存在，加入收藏的话，会出现修改成功的提示，实际应该返回错误的
				{ "", cartid1, cartid2, 1, "修改成功" }, { cartid3 + ":2", cartid1, cartid2, 1, "修改成功" },
				{ cartid3 + ":2" + ";" + cartid4 + ":2", cartid1 + "," + cartid2, cartid5 + "," + cartid6, 1, "修改成功" },
				{ cartid3 + "：2" + ";" + cartid4 + ":2", cartid1 + "," + cartid2, cartid5 + "," + cartid6, -1,
						"数据格式异常" },
				{ cartid3 + ":2" + "|" + cartid4 + ":2", cartid1 + "," + cartid2, cartid5 + "," + cartid6, -1,
						"数据格式异常" },
				{ cartid3 + ":2" + ";" + cartid4 + ":2", cartid1 + "。" + cartid2, cartid5 + "," + cartid6, -1,
						"数据格式异常" },
				{ cartid3 + ":2" + ";" + cartid4 + ":2", cartid1 + "," + cartid2, cartid5 + "。" + cartid6, -1,
						"数据格式异常" }, };
	}

	/**
	 * /cart/checkout-single
	 * 
	 * @param Num
	 * @param ActivityID
	 * @param ProductID
	 * @param Specific
	 * @param SkuID
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "checkoutSingle", dataProviderClass = CartData.class)
	public void checkoutSingle(String Num, String ActivityID, String ProductID, String Specific, String SkuID,
			Object flag, String msg) {
		// 获取响应
		JSONObject response = cart.checkoutSingle(Num, ActivityID, ProductID, Specific, SkuID);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	/**
	 * /cart/checkout
	 * 
	 * @param CartIDs
	 * @param SellerIDs
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "checkout")
	public void checkout(String CartIDs, String SellerIDs, Object flag, String msg) {
		// 获取响应
		JSONObject response = cart.checkout(CartIDs, SellerIDs);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			// 验证响应中包含了对应cartid
			String[] carts = CartIDs.split(",");
			for (int i = 0; i < carts.length; i++) {
				Assert.assertTrue(response.toString().contains(carts[i]), "cartid没有包含在结算响应中");
			}
		}
	}

	@DataProvider(name = "checkout")
	public Object[][] checkout() {
		String cartid1 = getCartID("1", "4309530", "3314");
		String cartid2 = getCartID("1", "4080581", "1152");
		return new Object[][] { { "", "", -1, "" }, { "null", "null", -1, "" }, { null, null, -1, "" },
				{ cartid1, "1559342", 1, "添加至下单确认页成功" }, { cartid1, "", 1, "添加至下单确认页成功" },
				{ cartid1, "null", 1, "添加至下单确认页成功" }, { cartid1, null, 1, "添加至下单确认页成功" },
				{ cartid1, "11111", 1, "添加至下单确认页成功" }, { cartid1, "wrong", 1, "添加至下单确认页成功" },
				{ "1111111", "1559342", -1, "抱歉，所选商品已下架" }, { "wrong", "1559342", -1, "未查询到下单商品信息" },
				{ "", "1559342", -1, "" }, { "null", "1559342", -1, "" }, { null, "1559342", -1, "" },
				{ cartid1 + "," + cartid2, "1559342", 1, "添加至下单确认页成功" },
				{ cartid1 + "，" + cartid2, "1559342", -1, "参数错误" } // 参数错误，目前会截取第一个商品的cartid，舍弃后一个，应该直接返回参数错误吧？
		};
	}

	/**
	 * /cart/edit
	 * 
	 * @param CartID
	 * @param Num
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "edit")
	public void edit(String CartID, String Num, Object flag, String msg) {
		// 获取响应
		JSONObject response = cart.edit(CartID, Num);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			// 验证响应中包含了对应cartid
			Assert.assertTrue(response.toString().contains(CartID), "cartid没有包含在编辑响应中");
		}
	}

	@DataProvider(name = "edit")
	public Object[][] edit() {
		String cartid1 = getCartID("1", "4309530", "3314");
		return new Object[][] { { "", "", -1, "数量不能为0" }, { "null", "null", -1, "数量不能为0" },
				{ null, null, -1, "数量不能为0" }, { getCartID("1", "4309530", "3314"), "5", 1, "修改成功" },
				{ cartid1, "", -1, "数量不能为0" }, { cartid1, "null", -1, "数量不能为0" }, { cartid1, null, -1, "数量不能为0" },
				{ cartid1, "11111", -1, "商品库存不足" }, { cartid1, "wrong", -1, "数量不能为0" },
				{ "1111111", "1", -1, "对不起，您无权修改此购物车" }, { "wrong", "1", -1, "ID不能为空" }, { "", "1", -1, "ID不能为空" },
				{ "null", "1", -1, "ID不能为空" }, { null, "1", -1, "ID不能为空" } };
	}

	// /**
	// * 这个创建订单操作和资金那边的create操作区别？
	// * @param SellerNotes
	// * @param SellerCoupons
	// * @param AddressID
	// * @param SellerFollows
	// * @param Coupon
	// * @param IdcardCode
	// * @param flag
	// * @param msg
	// */
	// @Test(dataProvider = "order")
	// public void order(String SellerNotes, String SellerCoupons, String
	// AddressID, String SellerFollows, String Coupon,
	// String IdcardCode, Object flag, String msg) {
	// // 获取响应
	// JSONObject response = cart.order(SellerNotes, SellerCoupons, AddressID,
	// SellerFollows, Coupon, IdcardCode);
	// // 验证响应
	// ResponseHelper.compareFlag(response, flag);
	// ResponseHelper.compareMsg(response, msg);
	// }

	/**
	 * /cart/get-confirm
	 * 
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "getConfirm", dataProviderClass = CartData.class)
	public void getConfirm(Object flag, String msg) {
		// 获取响应
		JSONObject response = cart.getConfirm();
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	/**
	 * /cart/clear-invalid-products 但是此接口无法测试实际是否有清除成功，原因是无法保证购物车存在失效商品
	 * 
	 * @param SellerID
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "clearInvalidProduct", dataProviderClass = CartData.class)
	public void clearInvalidProduct(String SellerID, Object flag, String msg) {
		// 获取响应
		JSONObject response = cart.clearInvalidProduct(SellerID);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

}
