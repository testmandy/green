package com.haimi.hm.testcase;

import org.testng.annotations.Test;
import com.haimi.helper.ResponseHelper;
import net.sf.json.JSONObject;
import com.haimi.hm.data.FeedbackData;

/**
 * feedback
 * @author puff
 *
 */

public class FeedbackTest extends BaseTest {
	
	/**
	 * feedback/post
	 * @param Content
	 * @param Mobile
	 * @param Name
	 * @param flag
	 * @param msg
	 */

	@Test(dataProvider = "post", dataProviderClass = FeedbackData.class)
	public void post(String Content, String Mobile, String Name, Object flag, String msg) {
		// 获取响应
		JSONObject response = feedback.post(Content, Mobile, Name);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}
}
