package com.haimi.hm.testcase;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.haimi.helper.JSONHelper;
import com.haimi.helper.ResponseHelper;
import com.haimi.hm.data.AddressData;
import com.haimi.util.Tools;

import net.sf.json.JSONObject;

/**
 * address
 * 
 * @author iris
 *
 */
public class AddressTest extends BaseTest {

	/**
	 * 获取加地址后的addressid
	 * 
	 * @param Area
	 * @param Phone
	 * @param City
	 * @param Detail
	 * @param Province
	 * @param Name
	 * @return
	 */
	public String getAddressID(String Area, String Phone, String City, String Detail, String Province, String Name) {
		// 获取响应
		JSONObject response = address.add("null", Area, Phone, "null", City, Detail, Province, Name);
		// 验证响应
		ResponseHelper.compareFlag(response, 1);
		// 从response中获取addressid，验证后删除
		String addressid = (String) JSONHelper.getSonJSONKeyValue(response, "data", "AddressID");
		return addressid;
	}

	/**
	 * /address/list
	 * 
	 * @param IsDefault
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "list", dataProviderClass = AddressData.class)
	public void list(String IsDefault, Object flag, String msg) {
		// 获取响应
		JSONObject response = address.list(IsDefault);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	/**
	 * /address/add
	 * 
	 * @param IsDefault
	 * @param Area
	 * @param Phone
	 * @param Zipcode
	 * @param City
	 * @param Detail
	 * @param Province
	 * @param Name
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "add", dataProviderClass = AddressData.class)
	public void add(String IsDefault, String Area, String Phone, String Zipcode, String City, String Detail,
			String Province, String Name, Object flag, String msg) {
		// 获取响应
		JSONObject response = address.add(IsDefault, Area, Phone, Zipcode, City, Detail, Province, Name);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			// 从response中获取addressid，验证后删除
			String addressid = (String) JSONHelper.getSonJSONKeyValue(response, "data", "AddressID");
			Assert.assertTrue(addressid != null, "增加新地址后，id为空");
			// 删除id
			JSONObject delresponse = address.delete(addressid);
			// 验证响应
			ResponseHelper.compareFlag(delresponse, 1);
		}
	}

	/**
	 * /address/delete
	 * 
	 * @param AddressID
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "delete")
	public void delete(String AddressID, Object flag, String msg) {
		// 获取响应
		JSONObject response = address.delete(AddressID);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	@DataProvider(name = "delete")
	public Object[][] delete() {
		return new Object[][] {
				{ getAddressID("东城区", "13000000003", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5)), 1, "删除成功" },
				{ "", -1, "没有找到此条记录" }, { "null", -1, "没有找到此条记录" }, { null, -1, "没有找到此条记录" },
				{ "wrong", -1, "您无权进行此操作" }, { "11111111", -1, "您无权进行此操作" } };
	}

	/**
	 * /address/edit
	 * 
	 * @param IsDefault
	 * @param Area
	 * @param Phone
	 * @param Zipcode
	 * @param City
	 * @param AddressID
	 * @param Detail
	 * @param Province
	 * @param Name
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "edit")
	public void edit(String IsDefault, String Area, String Phone, String Zipcode, String City, String AddressID,
			String Detail, String Province, String Name, Object flag, String msg) {
		// 获取响应
		JSONObject response = address.edit(IsDefault, Area, Phone, Zipcode, City, AddressID, Detail, Province, Name);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			// 验证编辑成功
			JSONObject listresponse = address.list("null");
			// 验证响应
			ResponseHelper.compareFlag(listresponse, 1);
			Assert.assertTrue(listresponse.toString().contains(Name), "重新编辑后的地址列表中，没有指定的name的地址");
			// 删除id
			JSONObject delresponse = address.delete(AddressID);
			// 验证响应
			ResponseHelper.compareFlag(delresponse, 1);
		}
	}

	@DataProvider(name = "edit")
	public Object[][] edit() {
		return new Object[][] {
				{ "null", "东城区", "13000000003", "null", "北京市",
						getAddressID("东城区", "13000000003", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
								Tools.getRandomString(5)),
						"这里是详细地址" + Tools.getTimeStamp(), "北京市", Tools.getRandomString(5), 1, "修改地址成功" },
				{ "null", "东城区", "13000000003", "null", "北京市", null, "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), -1, "地址ID不能为空" },
				{ "null", "东城区", "13000000003", "null", "北京市", "null", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), -1, "地址ID不能为空" },
				{ "null", "东城区", "13000000003", "null", "北京市", "", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5), -1, "地址ID不能为空" } };
	}

	/**
	 * /address/set-default
	 * 
	 * @param AddressID
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "setDefault")
	public void setDefault(String AddressID, Object flag, String msg) {
		// 获取响应
		JSONObject response = address.setDefault(AddressID);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			// 验证设置成功
			JSONObject listresponse = address.list("null");
			// 验证响应
			ResponseHelper.compareFlag(listresponse, 1);
			JSONObject addressIndex = JSONHelper.getArraySonJSON(listresponse, "data", 0);
			String isDefault = addressIndex.getString("IsDefault");
			Assert.assertTrue("Y".equals(isDefault), "设置默认后，没有变成Y");
			// 删除id
			JSONObject delresponse = address.delete(AddressID);
			// 验证响应
			ResponseHelper.compareFlag(delresponse, 1);
		}
	}

	@DataProvider(name = "setDefault")
	public Object[][] setDefault() {
		return new Object[][] { { "", -1, "" }, { "null", -1, "" }, { null, -1, "" }, { "wrong", -1, "" }, // 错误的addressid没有验证
				{ "111111111", -1, "" }, // 错误的addressid没有验证
				{ "1", -1, "" }, // 别人的id，没有验证权限问题
				{ getAddressID("东城区", "13000000003", "北京市", "这里是详细地址" + Tools.getTimeStamp(), "北京市",
						Tools.getRandomString(5)), 1, "设置成功" } };
	}

}
