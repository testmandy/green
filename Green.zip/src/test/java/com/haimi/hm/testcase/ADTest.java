package com.haimi.hm.testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.haimi.helper.JSONHelper;
import com.haimi.helper.ResponseHelper;
import com.haimi.hm.data.ADData;
import com.haimi.r.DBData;

import net.sf.json.JSONObject;

/**
 * 广告测试类
 * 
 * @author iris
 *
 */
public class ADTest extends BaseTest {

	/**
	 * 测试路径："/ad-module/get" 获取一个广告位所包含的所有模块信息
	 * 
	 * @param Alias
	 * @param Date
	 * @param BelongTo
	 * @param Scene
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "adModuleGet", dataProviderClass = ADData.class)
	public void adModuleGet(String Alias, String AdModuleID, String Date, String BelongTo, String Scene, int flag,
			String msg) {
		// 获取广告模块响应
		JSONObject response = ad.adModuleGet(Alias, AdModuleID, Date, BelongTo, Scene);
		// 判断响应的flag
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if (flag != -1) {
			String nameActual = (String) JSONHelper.getSonJSONKeyValue(response, "extra", "Name");
			String nameExcepted;
			if (Alias == null || "".equals(Alias) || "null".equals(Alias)) {
				nameExcepted = DBData.getAdModuleNameByID(AdModuleID);
			} else {
				nameExcepted = DBData.getAdModuleNameByAlias(Alias);
			}
			Assert.assertEquals(nameActual, nameExcepted, "广告的name不相同！");
		}
	}

	/**
	 * 获取个性化广告位所包含的所有模块信息 /ad-module/dynamic
	 * 
	 * @param Alias
	 * @param Date
	 * @param BelongTo
	 * @param Scene
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "adModuleDynamic", dataProviderClass = ADData.class)
	public void adModuleDynamic(String Alias, String Date, String BelongTo, String Scene, int flag, String msg) {
		// 获取广告模块响应
		JSONObject response = ad.adModuleDynamic(Alias, Date, BelongTo, Scene);
		// 判断响应的flag
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}
}
