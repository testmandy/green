package com.haimi.hm.testcase;

import org.apache.http.client.CookieStore;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.haimi.helper.CookiesHelper;
import com.haimi.helper.JSONHelper;
import com.haimi.helper.ResponseHelper;
import com.haimi.hm.page.AD;
import com.haimi.hm.page.Address;
import com.haimi.hm.page.Cart;
import com.haimi.hm.page.Easemob;
import com.haimi.hm.page.Escrow;
import com.haimi.hm.page.Favorite;
import com.haimi.hm.page.Feedback;
import com.haimi.hm.page.Invite;
import com.haimi.hm.page.Me;
import com.haimi.hm.page.System;
import com.haimi.hm.page.User;
import com.haimi.hm.page.Member;
import com.haimi.hm.page.Nav;
import com.haimi.hm.page.Search;
import com.haimi.r.R;

import net.sf.json.JSONObject;

/**
 * 海蜜测试基类
 * 
 * @author iris
 *
 */
public class BaseTest {

	// cookie存储
	CookieStore cookieStore;

	// 登录用户id记录
	String memberid;

	// 实例化
	static Member member;
	System system;
	Easemob easemob;
	AD ad;
	Invite invite;
	Me me;
	Cart cart;
	Address address;
	User user;
	Search search;
	Nav nav;
	Favorite favorite;
	Feedback feedback;
	Escrow escrow;

	/**
	 * 设置cookie信息，构造cookie 构造各个方法类的实例
	 * 
	 * @param version
	 * @param appname
	 * @param platform
	 */
	@Parameters({ "version", "appname", "platform", "username", "password" })
	@BeforeClass(alwaysRun = true)
	public void setup(@Optional("4.0.0") String version, @Optional("haimi") String appname,
			@Optional("IOS") String platform, @Optional("13000000003") String username,
			@Optional("qa1234") String password) {
		// 伪造cookie
		cookieStore = CookiesHelper.setCookie(R.BASEURL, version, appname, platform);

		// 构造实例
		member = new Member(cookieStore);
		system = new System(cookieStore);
		easemob = new Easemob(cookieStore);
		ad = new AD(cookieStore);
		invite = new Invite(cookieStore);
		me = new Me(cookieStore);
		cart = new Cart(cookieStore);
		address = new Address(cookieStore);
		user = new User(cookieStore);
		search = new Search(cookieStore);
		nav = new Nav(cookieStore);
		favorite = new Favorite(cookieStore);
		feedback = new Feedback(cookieStore);
		escrow = new Escrow(cookieStore);

		// 登录，获取登录cookie
		JSONObject response = member.login(username, password, "null", "null", "null", "null");

		// 登录成功获得memberid初始值
		ResponseHelper.compareFlag(response, 1);
		memberid = (String) JSONHelper.getSonJSONKeyValue(response, "data", "MemberID");

	}

	/**
	 * 退出登录
	 */
	@AfterClass(alwaysRun = true)
	public void teardown() {
		if (memberid != null) {
			member.logout();
			memberid = null;
		}
	}
}
