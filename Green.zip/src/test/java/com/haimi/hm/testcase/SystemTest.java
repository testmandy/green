package com.haimi.hm.testcase;

import java.sql.Timestamp;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.haimi.helper.ResponseHelper;
import com.haimi.hm.data.SystemData;
import com.haimi.r.DBData;
import com.haimi.helper.JSONHelper;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * 系统api
 * 
 * @author iris
 *
 */

public class SystemTest extends BaseTest {

	/**
	 * 测试路径："/system/get-config" 系统配置接口的key传值测试
	 * 
	 * @param keys
	 * @param flag
	 */
	@Test(dataProvider = "getConfig", dataProviderClass = SystemData.class)
	public void getConfig(String keys, String isLogin, int flag, String msg) {
		// 获取config
		JSONObject response = system.getConfig(keys, isLogin);
		// 比较
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);

		if (keys == null || "".equals(keys) || "null".equals(keys)) {
			// 判断顶部搜索默认占位符和顶部搜索默认搜索词与配置或数据库是否相同
			JSONArray searchPlaceholderActual = response.getJSONObject("data").getJSONArray("SearchPlaceholder");
			String searchPlaceholder = DBData.getConfigContent("SearchPlaceholder");
			JSONArray searchPlaceholderExcepted = JSONArray.fromObject(searchPlaceholder);
			Assert.assertEquals(searchPlaceholderActual, searchPlaceholderExcepted, "SearchPlaceholder数据库与实际获取不一致");

			// 获取登录用户和非登录用户的不同返回，进行比较
			String defaultIndexActual = (String) JSONHelper.getSonJSONKeyValue(response, "data", "DefaultIndex");
			String defaultIndexExcepted = DBData.getConfigContent("DefaultIndex");
			Assert.assertEquals(defaultIndexActual, defaultIndexExcepted, "DefaultIndex数据库与实际获取不一致");
		} else {
			// key的比较
			String[] key = keys.split(",");
			for (int i = 0; i < key.length; i++) {
				Object keyActual = JSONHelper.getSonJSONKeyValue(response, "data", key[i]);
				String keyExcepted = DBData.getConfigContent(key[i]);
				Assert.assertEquals(keyActual.toString(), "" + keyExcepted, key[i] + "数据库与实际获取不一致");
			}
		}
	}

	/**
	 * 测试路径："/system/no-answer-chat" 记录客户端传过来的未回复会话
	 * 
	 * @param id
	 * @param flag
	 */
	@Test(dataProvider = "noAnswerChat", dataProviderClass = SystemData.class)
	public void noAnswerChat(String id, int flag, String msg) {
		// 客户端传id
		JSONObject response = system.noAnswerChat(id);
		// 判断返回是否正确
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if (flag == 1) {
			// 查询数据库确保id写入,如果传入id是，分隔，则只比较最后一个
			String result = DBData.getnoAnswerChat(memberid);
			String ids[] = id.split(",");
			Assert.assertEquals(ids[ids.length - 1], result, "id记录与数据库不同");
		}
	}

	/**
	 * 测试路径："/system/log-device-notification-status" 记录用户设备是否开启通知
	 * 
	 * @param NotificationStatus
	 * @param deviceID
	 * @param flag
	 */
	@Test(dataProvider = "logDeviceNotificationStatus", dataProviderClass = SystemData.class)
	public void logDeviceNotificationStatus(String NotificationStatus, String deviceID, int flag, String msg) {
		// 客户端传id
		JSONObject response = system.logDeviceNotificationStatus(NotificationStatus, deviceID);
		// 判断返回是否正确
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if (flag == 1) {
			String statusActual = DBData.getlogDeviceNotificationStatus(deviceID);
			String statusExcepted = NotificationStatus;
			if ("Y".equals(statusExcepted)) {
				statusExcepted = "Y";
			} else {
				statusExcepted = "N";
			}
			Assert.assertEquals(statusActual, statusExcepted, "通知的开关状态不同");
		}
	}

	/**
	 * 测试路径："/system/get-meipai-video-url" 通过美拍网页链接，解析出美拍视频链接
	 * 
	 * @param url
	 * @param flag
	 */
	@Test(dataProvider = "getMeipaiVideoUrl", dataProviderClass = SystemData.class)
	public void getMeipaiVideoUrl(String url, int flag, String msg) {
		// 根据url进行解析
		JSONObject response = system.getMeipaiVideoUrl(url);
		// 响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		// 判断解析的url是否符合预期
		if (flag == 1) {
			String vediourl = (String) JSONHelper.getSonJSONKeyValue(response, "data", "VideoUrl");
			Assert.assertTrue(vediourl.endsWith(".mp4"), "解析结果不正确,非.mp4结尾");
		}
	}

	/**
	 * getTime 获取系统时间
	 * 
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "getTime", dataProviderClass = SystemData.class)
	public void getTime(int flag, String msg) {
		JSONObject response = system.getTime();
		// 响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		// 判断
		if (flag == 1) {
			int stamp = (int) JSONHelper.getSonJSONKeyValue(response, "data", "stamp");
			int time = (int) (System.currentTimeMillis() / 1000);
			Assert.assertTrue((time - stamp) <= 1, "服务器时间和本地时间差距过大");
		}
	}

	/**
	 * getSettingInfo 获取系统配置信息，只有海蜜的联系和微信号
	 * 
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "getSettingInfo", dataProviderClass = SystemData.class)
	public void getSettingInfo(int flag, String msg) {
		JSONObject response = system.getSettingInfo();
		// 响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		// 判断
		if (flag == 1) {
			String haimiactual = (String) JSONHelper.getSonJSONKeyValue(response, "data", "haimi_weixin");
			String haimiexcepted = "haimicom";
			Assert.assertEquals(haimiactual, haimiexcepted, "微信的设定不同");
		}
	}

	/**
	 * isUploadCrashLog 客户端是否要上传crash日志
	 * 
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "isUploadCrashLog", dataProviderClass = SystemData.class)
	public void isUploadCrashLog(Object flag, String msg) {
		// 获取响应
		JSONObject response = system.isUploadCrashLog();
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			String isuploadactual = (String) JSONHelper.getSonJSONKeyValue(response, "data", "IsUpload");
			String isuploadexcepted = "N";
			Assert.assertEquals(isuploadactual, isuploadexcepted, "本测试账号为不需要上传crash信息的，但是现在预期不符合");
		}
	}

	/**
	 * apiPorts 获取api服务器列表
	 * 
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "apiPorts", dataProviderClass = SystemData.class)
	public void apiPorts(Object flag, String msg) {
		// 获取响应
		JSONObject response = system.apiPorts();
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			Assert.assertTrue(response.toString().contains("api.haimi.com"), "apiports接口没有主ip");
		}
	}

	/**
	 * app是否需要升级
	 * 
	 * @param platform
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "appUpdate", dataProviderClass = SystemData.class)
	public void appUpdate(String platform, Object flag, String msg) {
		// 获取响应
		JSONObject response = system.appUpdate(platform);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	/**
	 * ping服务器
	 * 
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "ping", dataProviderClass = SystemData.class)
	public void ping(Object flag, String msg) {
		// 获取响应
		JSONObject response = system.ping();
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			Assert.assertTrue(response.toString().contains("pong"), "ping的echo返回不对");
		}
	}

	/**
	 * 保存最后登录时间
	 * 
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "saveLoginTime", dataProviderClass = SystemData.class)
	public void saveLoginTime(Object flag, String msg) {
		// 获取响应
		JSONObject response = system.saveLoginTime();
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			Timestamp time = DBData.getLastLoginTime(memberid);
			long excepted = time.getTime() / 1000;
			long actual = System.currentTimeMillis() / 1000;
			Assert.assertTrue((actual - excepted) <= 100, "服务器时间和本地时间差距过大");
		}
	}

	/**
	 * 获取应用启动图。存在多个取第一个。 /system/startup-images
	 * 
	 * @param BelongTo
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "startupImages", dataProviderClass = SystemData.class)
	public void startupImages(String BelongTo, Object flag, String msg) {
		// 获取响应
		JSONObject response = system.startupImages(BelongTo);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	/**
	 * /system/get-extra-app-info
	 * 
	 * @param platform
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "getExtraAppInfo", dataProviderClass = SystemData.class)
	public void getExtraAppInfo(String platform, Object flag, String msg) {
		// 获取响应
		JSONObject response = system.getExtraAppInfo(platform);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	/**
	 * /system/get-brands
	 * 
	 * @param Recommend
	 * @param key
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "getBrands", dataProviderClass = SystemData.class)
	public void getBrands(String Recommend, String key, Object flag, String msg) {
		// 获取响应
		JSONObject response = system.getBrands(Recommend, key);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			int total = (int) JSONHelper.getSonJSONKeyValue(response, "extra", "total");
			Assert.assertTrue(total > 0, "总品牌数量为0");
		}
	}

	/**
	 * /system/faq
	 * 
	 * @param CategoryID
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "faq", dataProviderClass = SystemData.class)
	public void faq(String CategoryID, Object flag, String msg) {
		// 获取响应
		JSONObject response = system.faq(CategoryID);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if ((int) flag == 1) {
			if ("18".equals(CategoryID)) {
				Assert.assertTrue(response.toString().contains("移动端-买家"), "买家帮助文档未包含买家字样");
			} else if ("19".equals(CategoryID)) {
				Assert.assertTrue(response.toString().contains("移动端-买手"), "卖家帮助文档未包含卖家字样");
			}
		}
	}

	/**
	 * /system/get-refund-reason
	 * 
	 * @param IsTakeover
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "getRefundReason", dataProviderClass = SystemData.class)
	public void getRefundReason(String IsTakeover, Object flag, String msg) {
		// 获取响应
		JSONObject response = system.getRefundReason(IsTakeover);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	/**
	 * /system/get-recommend-products
	 * 
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "getRecommendProducts", dataProviderClass = SystemData.class)
	public void getRecommendProducts(Object flag, String msg) {
		// 获取响应
		JSONObject response = system.getRecommendProducts();
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	/**
	 * /system/getrecommend
	 * 
	 * @param page
	 * @param pageSize
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "getRecommend", dataProviderClass = SystemData.class)
	public void getRecommend(String page, String pageSize, Object flag, String msg) {
		// 获取响应
		JSONObject response = system.getRecommend(page, pageSize);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}
}
