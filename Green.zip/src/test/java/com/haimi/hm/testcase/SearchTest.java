package com.haimi.hm.testcase;

import java.util.HashMap;

import org.testng.annotations.Test;
import com.haimi.helper.ResponseHelper;
import net.sf.json.JSONObject;
import com.haimi.hm.data.SearchData;

/**
 * search
 * 
 * @author iris
 *
 */
public class SearchTest extends BaseTest {

	/**
	 * /search/hotword
	 * 
	 * @param type
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "hotword", dataProviderClass = SearchData.class)
	public void hotword(String type, Object flag, String msg) {
		// 获取响应
		JSONObject response = search.hotword(type);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	/**
	 * /search/suggest
	 * 
	 * @param Key
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "suggest", dataProviderClass = SearchData.class)
	public void suggest(String Key, Object flag, String msg) {
		// 获取响应
		JSONObject response = search.suggest(Key);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}

	/**
	 * /search/product
	 * 
	 * @param map
	 * @param flag
	 * @param msg
	 */
	@Test(dataProvider = "product", dataProviderClass = SearchData.class)
	public void product(HashMap<String, String> map, Object flag, String msg) {
		// 获取响应
		JSONObject response = search.product(map);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
	}
}
