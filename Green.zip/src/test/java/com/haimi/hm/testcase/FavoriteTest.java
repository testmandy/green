package com.haimi.hm.testcase;

import org.testng.annotations.Test;
import com.haimi.helper.ResponseHelper;
import net.sf.json.JSONObject;
import com.haimi.hm.data.FavoriteData;

/**
 * favorite
 * 
 * @author puff
 *
 */
public class FavoriteTest extends BaseTest {
	
	/**
	 * favorite/product
	 * @param HmSource
	 * @param ProductID
	 * @param flag
	 * @param msg
	 */
	
	@Test(dataProvider = "product", dataProviderClass = FavoriteData.class)
	public void product(String username, String password, String HmSource, String ProductID, Object flag, String msg) {
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
		}
		// 获取响应
		JSONObject response = favorite.product(HmSource, ProductID);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
		}
	}
	
	/**
	 * favorite/product-cancel
	 * @param ProductID
	 * @param flag
	 * @param msg
	 */

	@Test(dataProvider = "productCancel", dataProviderClass = FavoriteData.class)
	public void productCancel(String username, String password, String ProductID, Object flag, String msg) {
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
		}
		// 获取响应
		JSONObject response = favorite.productCancel(ProductID);
		// 验证响应
		ResponseHelper.compareFlag(response, flag);
		ResponseHelper.compareMsg(response, msg);
		if (!username.isEmpty()) {
			JSONObject reslogin = member.login(username, password, "", "", "", "");
			ResponseHelper.compareFlag(reslogin, 1);
		}
	}
}
