介绍

构建工具：maven

构建环境：online，offline，test

构建参数：version，appname，platform,xmlfile


用例组织：testng

参数传递：xml属性指定


测试报告：reportng


测试log：log4j

文件：daily.log,error.log,info.log


测试数据：excel or TDataProvider


说明：

第三方登录的接口，由于微博，qq，微信等的登录无法进行模拟，access_token（qqtoken的时间是3个月，但是微博只有7天）无法在过期后自动获取，人工修改的成本太大，故不做


命名规则


CommonStrings：使用分类_接口命名特点，例如：/member/quick-login可以命名为：mem_quick_login.

Fun:功能方法使用接口命名特点，第一个字母小写，第二个单词首字母大写，例如：/member/quick-login可以命名为：loginQuick

Test：测试方法使用功能方法接口命名，增加test和测试点，例如：loginQuick可以命名为：testLoginQuick 或者 testLoginQuickAll

provider：测试数据分组，使用接口特点+测试特点，例如：testLoginQuickAll 可以命名：login_quick_all


用例编写：

1.新增url到CommonStrings

2.增加功能方法到对应的FUN

3.新增对应的测试方法到testcase

4.增加用例输入方法到provider
